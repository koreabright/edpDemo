<?php

namespace App\Console;

use Illuminate\Console\Command;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\Inspire::class,
        Commands\Customer\MigrateTradeTags::class,
        Commands\Customer\InitialCreateTaskType::class,
        Commands\CustomerClue\UpdateClueBD::class,
        Commands\Customer\AddFeatureForSubAccount::class,
        Commands\Driver\ConsoleFileForFraud::class,
        Commands\Customer\AddWaterMarkToHistoryCompany::class,
        Commands\Customer\ChargeProjectOperationField::class,
        Commands\Customer\FixCustomerSalesField::class,
        Commands\Customer\CustomerAwakeSms::class,
        Commands\Customer\CustomerPromptSms::class,
        Commands\Customer\CluePromptSms::class,
        Commands\Customer\SpiderCluePromptSms::class,
        Commands\AdminUser\UpdateAdminUserADC::class,
        Commands\Customer\UpdateCustomerCompanyName::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('inspire')
                 ->hourly();
    }
}
