<?php

namespace App\Console\Commands\AdminUser;

use Illuminate\Console\Command;

use App\Repositories\AdminUserRepository;
use App\Repositories\AdcRepository;

use App\Exceptions\BeeperException;
use Log;

class UpdateAdminUserADC extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'admin_user:update_adc {--dry_run=0} {--admin_user_ids=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '更新用户管理区';
    
    private $adminUserRepos;
    private $adcRepos;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(AdminUserRepository $adminUserRepos, AdcRepository $adcRepos)
    {
        $this->adminUserRepos = $adminUserRepos;
        $this->adcRepos = $adcRepos;
        
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::info('update_adc: Begin update admin ADC');
        if ($this->option('dry_run')) {
            $this->info('---Dry run---');
        }
        
        $params = ['is_delete' => 0];
        if (!empty($this->option('admin_user_ids'))) {
            $params['admin_user_ids'] = explode(',', $this->option('admin_user_ids'));
        }
        $userList = $this->getUserList($params);
        
        foreach ($userList as $user) {
            try {
                $this->updateAdc($user);
            } catch (\Exception $error) {
                Log::error('update_adc: user ' . json_encode($user) .
                    ', file: ' . $error->getFile() . ', line: ' . $error->getLine() .
                    ', message: ' . $error->getMessage());
                if ($this->option('dry_run')) {
                    $this->error($error->getTraceAsString());
                }
            }
        }
        Log::info('update_adc: End update admin ADC');
    }
    
    private function getUserList($params)
    {
        $params['page'] = 1;
        
        while (1) {
            $response = $this->adminUserRepos->gets($params);
            $params['page']++;
            
            $page = array_get($response, 'pagination.page');
            $totalPage = array_get($response, 'pagination.total_pages');
            $list = array_get($response, 'list', []);
            
            foreach ($list as $adminUser) {
                yield $adminUser;
            }
            
            if (empty($list) || $page >= $totalPage) {
                break;
            }
        }
    }
    
    private function updateAdc($user)
    {
        if (array_get($user, 'is_national')) {
            $this->updateNationalAdc($user);
        } elseif (!empty(array_get($user, 'regions'))) {
            $this->updateRegions($user);
        }
    }
    
    private function updateNationalAdc($user)
    {
        $updateParams = [];
        
        $adminUserId = array_get($user, 'admin_user_id');
        $configRegions = config('administrative_city.adc_regions');
        $userRegions = array_get($user, 'regions', []);
        //Append lack regions
        $lackRegions = array_diff($configRegions, $userRegions);
        if (!empty($lackRegions)) {
            $updateParams['regions'] = array_merge($userRegions, $lackRegions);
            
            if ($this->option('dry_run')) {
                $this->info($adminUserId . ' by national: regions from ' . implode(',', $userRegions) .
                    ' to ' . implode(',', array_merge($userRegions, $lackRegions)));
            }
        }
        
        $adcIds = $this->getAllAdcIds();
        $userAdcIds = array_get($user, 'adcids', []);
        //Apend lack adc ids
        $lackAdcIds = array_diff($adcIds, $userAdcIds);
        if (!empty($lackAdcIds)) {
            $updateParams['adcids'] = array_merge($userAdcIds, $lackAdcIds);
            
            if ($this->option('dry_run')) {
                $this->info($adminUserId . ' by national: adc ids from ' . implode(',', $userAdcIds) .
                    ' to ' . implode(',', array_merge($userAdcIds, $lackAdcIds)));
            }
        }
        
        if (!empty($updateParams)) {
            if (!$this->option('dry_run')) {
                $this->adminUserRepos->update([
                    'where' => ['_id' => $adminUserId],
                    'set_data' => $updateParams,
                ]);
            }
            
            Log::info('update_adc: ' . ' update national admin user: ' . array_get($user, 'admin_user_id') .
                'adc ids from ' . json_encode($userAdcIds) .
                ', params: ' . json_encode($updateParams));
        } else {
            Log::info('update_adc: ' . ' no need to update national admin user: ' .
                array_get($user, 'admin_user_id'));
            if ($this->option('dry_run')) {
                $this->info('update_adc: ' . ' no need to update national admin user: ' .
                    array_get($user, 'admin_user_id'));
            }
        }
    }
    
    private $adcCache = null;
    private function getAllAdcs()
    {
        if (is_null($this->adcCache)) {
            $this->adcCache = [];
            
            $params['page'] = 0;
            while (1) {
                $response = $this->adcRepos->gets($params);
                $params['page']++;
                
                $page = array_get($response, 'pagination.page');
                $totalPage = array_get($response, 'pagination.total_pages');
                $list = array_get($response, 'list', []);
                
                foreach ($list as $adc) {
                    //去除哥谭市
                    if (array_get($adc, 'adcid') != 5) {
                        $this->adcCache[] = $adc;
                    }
                }
                
                if (empty($list) || $page >= $totalPage) {
                    break;
                }
            }
        }
        return $this->adcCache;
    }
    
    private function getAllAdcIds()
    {
        $adcs = $this->getAllAdcs();
        return array_column($adcs, 'adcid');
    }
    
    private function getRegionsAdcIds($regions)
    {
        $result = [];
        foreach ($this->getAllAdcs() as $adc) {
            $matchRegions = array_intersect($regions, array_get($adc, 'tags', []));
            $matchRegions = array_filter($matchRegions);
            
            if (!empty($matchRegions)) {
                $result[] = array_get($adc, 'adcid');
            }
        }
        
        return $result;
    }
    
    private function updateRegions($user)
    {
        $regions = array_get($user, 'regions', []);
        
        $adcIds = $this->getRegionsAdcIds($regions);
        $userAdcIds = array_get($user, 'adcids', []);
        
        $lackAdcIds = array_diff($adcIds, $userAdcIds);
        if (!empty($lackAdcIds)) {
            $adminUserId = array_get($user, 'admin_user_id');
            $newAdcIds = array_merge($userAdcIds, $lackAdcIds);
            $updateParams = [
                'adcids' => $newAdcIds,
            ];
            
            Log::info('update_adc: ' . ' update regions admin user: ' . array_get($user, 'admin_user_id') .
                'adc ids from ' . json_encode($userAdcIds) .
                ', params: ' . json_encode($updateParams));
            
            if ($this->option('dry_run')) {
                $this->info($adminUserId . ' by region: adc ids from ' . implode(',', $userAdcIds) .
                    ' to ' . implode(',', $newAdcIds));
            } else {
                $this->adminUserRepos->update([
                    'where' => ['_id' => $adminUserId],
                    'set_data' => $updateParams,
                ]);
            }
        } else {
            if ($this->option('dry_run')) {
                $this->info('update_adc: ' . ' no need to update region admin user: ' .
                    array_get($user, 'admin_user_id'));
            }
            Log::info('update_adc: ' . ' no need to update region admin user: ' .
                array_get($user, 'admin_user_id'));
        }
    }
}
