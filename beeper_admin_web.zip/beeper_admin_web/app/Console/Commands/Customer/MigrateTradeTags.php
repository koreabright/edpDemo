<?php

namespace App\Console\Commands\Customer;

use App\Exceptions\BeeperException;
use Illuminate\Console\Command;
use YnRequest;
use Log;

class MigrateTradeTags extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migrate_trade_tags {customer_id?} {--force}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '迁移客户行业分类标签';

    /**
     * Create a new command instance.
     *
     *
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::custom('migrate_trade_tags')->info('=========开始迁移客户行业分类=========');

        $url = config('api.base_api.customer.get_profile_by_field');
        $perpage = 100;
        $page = 1;
        $customerId = $this->argument('customer_id');
        $forceUpdate = $this->option('force');

        while (true) {
            $params = [
                'from' => config('app.app_from'),
                'perpage' => $perpage,
                'page' => $page,
                'fields' => 'customer_id,trade_tags,cargo_type,consignee_type'
            ];

            if (!empty($customerId)) {
                $params['customer_id'] = $customerId;
            }

            $response = json_decode(YnRequest::get($url, $params, []), true);

            if (array_get($response, 'code') != 0) {
                throw new BeeperException(array_get($response, 'msg', '获取客户信息发生错误'));
            }

            $customerList = array_get($response, 'info.list', []);

            Log::custom('migrate_trade_tags')->info(
                sprintf(
                    '迁移到第 %s 页，共 %s 页',
                    $page,
                    array_get($response, 'info.pagination.total_pages', '')
                )
            );

            $this->migrateTradeTags($customerList, $forceUpdate);

            if (array_get($response, 'info.pagination.total_pages', '') == $page) {
                break;
            }

            $page ++;
        }

        Log::custom('migrate_trade_tags')->info('=========迁移客户行业分类完成=========');
    }

    private function migrateTradeTags($customerList, $forceUpdate)
    {
        $migrateData = [];

        foreach ($customerList as $customer) {
            $tradeTags = array_get($customer, 'trade_tags', []);
            $needUpdate = (array_get($customer, 'cargo_type.code', 0) == 0 &&
                array_get($customer, 'consignee_type.code', 0) == 0);

            //若客户只有一个行业分类，且（指定了--force，或者该客户没有更新过），则更新
            if (count($tradeTags) == 1 && ($forceUpdate || $needUpdate)) {
                $data = $this->transferTradeTags(array_get($tradeTags, '0.code'));
                if (empty($data) || (!$data[0] && !$data[1])) {
                    continue;
                }

                $params = ['query_customer_id' => $customer['customer_id']];

                if ($data[0]) {
                    $params['cargo_type'] = $data[0];
                }
                if ($data[1]) {
                    $params['consignee_type'] = $data[1];
                }

                $url = config('api.base_api.customer.update_profile_by_id');
                $response = json_decode(YnRequest::post($url, $params, []), true);

                if (array_get($response, 'code') != 0) {
                    $errorMsg = '更新客户信息错误: ' . array_get($response, 'msg') . ', request: ' . json_encode($params);
                    Log::custom('migrate_trade_tags')->error($errorMsg);
                } else {
                    $migrateData[] = [
                        'id' => $params['query_customer_id'],
                        'tag' => array_get($tradeTags, '0.code'),
                        'cargo' => $data[0],
                        'consignee' => $data[1]
                    ];
                }
            }
        }

        Log::custom('migrate_trade_tags')->info('更新数据：' . json_encode($migrateData));
    }

    private function transferTradeTags($tradeTag)
    {
        $result = [0, 0];
        switch ($tradeTag) {
            case config('customer.trade_industry.shang_chao.code'):
                $result[1] = config('customer.consignee_type.store.code');
                break;
            case config('customer.trade_industry.jia_dian.code'):
                $result[0] = config('customer.cargo_type.jia_dian.code');
                break;
            case config('customer.trade_industry.jia_ju.code'):
                $result[0] = config('customer.cargo_type.jia_ju.code');
                break;
            case config('customer.trade_industry.jian_cai.code'):
                $result[0] = config('customer.cargo_type.jian_cai.code');
                break;
            case config('customer.trade_industry.jiu_shui.code'):
                $result[0] = config('customer.cargo_type.jiu_shui.code');
                break;
            case config('customer.trade_industry.fu_zhuang.code'):
                $result[0] = config('customer.cargo_type.fu_shi.code');
                break;
            case config('customer.trade_industry.shi_cai.code'):
                $result[0] = config('customer.cargo_type.shi_cai.code');
                break;
            case config('customer.trade_industry.qi_pei.code'):
                $result[0] = config('customer.cargo_type.qi_pei.code');
                break;
            case config('customer.trade_industry.sheng_xian.code'):
                $result[0] = config('customer.cargo_type.shui_guo.code');
                break;
            case config('customer.trade_industry.xi_di.code'):
                $result[0] = config('customer.cargo_type.xi_di.code');
                break;
            case config('customer.trade_industry.yin_shua_pin.code'):
                $result[0] = config('customer.cargo_type.yin_shua_pin.code');
                break;
            case config('customer.trade_industry.yi_yao.code'):
                $result[0] = config('customer.cargo_type.yi_yao.code');
                break;
            case config('customer.trade_industry.mu_ying.code'):
                $result[0] = config('customer.cargo_type.mu_ying.code');
                break;
            case config('customer.trade_industry.xian_hua.code'):
                $result[0] = config('customer.cargo_type.xian_hua.code');
                break;
            case config('customer.trade_industry.shi_pin.code'):
                $result[0] = config('customer.cargo_type.fang_bian.code');
                break;
            case config('customer.trade_industry.shu_ma.code'):
                $result[0] = config('customer.cargo_type.3c_shu_ma.code');
                break;
            case config('customer.trade_industry.bao_zhuang.code'):
                $result[0] = config('customer.cargo_type.bao_zhuang.code');
                break;
            case config('customer.trade_industry.wu_jin.code'):
                $result[0] = config('customer.cargo_type.wu_jin.code');
                break;
            case config('customer.trade_industry.bian_li_dian.code'):
                $result[1] = config('customer.consignee_type.store.code');
                break;
            case config('customer.trade_industry.ri_hua.code'):
                $result[0] = config('customer.cargo_type.ri_hua.code');
                break;
            default:
                $result = [];
        }

        return $result;
    }
}
