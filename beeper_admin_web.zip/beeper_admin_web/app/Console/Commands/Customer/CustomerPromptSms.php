<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use App\Exceptions\BeeperException;
use App\Modules\Customer\Repositories\CustomerRepository;
use App\Modules\Customer\Repositories\AdminUserRepository;
use App\Modules\Customer\Repositories\CityRepository;
use App\Modules\Customer\Repositories\SmsRepository;
use App\Modules\Customer\Models\AdminUserModel;
use App\Repositories\WarehouseRepository;

use RequestsApi;
use Carbon\Carbon;
use Redis;

class CustomerPromptSms extends Command
{
    const SMS_PROMPT = 'sms_prompt';
    
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer:customer_prompt_sms {--dry_run=1}{--ignore_city_ids=}{--max_id=}{--skip=}{--limit=}{--init_last=0}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '发送客户促进开户短信';

    protected $customerRepository;
    protected $adminUserModel;
    protected $cityRepository;
    protected $smsRepository;
    
    protected $skipCount = 0;
    protected $runCount = 0;
    
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
        CustomerRepository $customerRepository,
        AdminUserModel $adminUserModel,
        CityRepository $cityRepository,
        SmsRepository $smsRepository
    ) {
        $this->customerRepository = $customerRepository;
        $this->adminUserModel = $adminUserModel;
        $this->cityRepository = $cityRepository;
        $this->smsRepository = $smsRepository;
        
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('dry_run')) {
            $this->info('Dry run:');
        }
        
        if ($this->option('init_last')) {
            $this->initLast();
            $this->info('Init last sms send finished');
            return;
        }
        
        RequestsApi::setCredential(false);
        
        $customerList = $this->getCustomerList();

        foreach ($customerList as $customer) {
            if ($this->skipCount < $this->option('skip')) {
                $this->skipCount++;
                continue;
            } elseif ($this->skipCount == $this->option('skip') && $this->runCount == 0) {
                $this->info('Skip customers: ' . $this->skipCount);
            }
            
            if (!empty($this->option('max_id'))) {
                if (array_get($customer, 'customer_id') > $this->option('max_id')) {
                    $this->info('Skip customer ' . array_get($customer, 'customer_id')
                        . ', it is larger than option max_id: ' . $this->option('max_id'));
                    continue;
                }
            }
            
            if ($this->runCount >= $this->option('limit')) {
                $this->info('Run customers: ' . $this->runCount);
                break;
            }
            $this->runCount++;
            
            try {
                $this->sendSms($customer);
            } catch (\Exception $e) {
                $this->error('customer id : '.array_get($customer, 'customer_id') .
                    ' , info '.json_encode($customer).' failed: '.$e->getMessage() .
                    ', file: ' . $e->getFile() . ', line: ' . $e->getLine());
            }
        }
    }
    
    private function getAdminUser($adminUserId)
    {
        $adminUser = $this->adminUserModel->getAdminUserByIdWithoutCredential($adminUserId);
        if (empty($adminUser)) {
            throw new BeeperException('Admin user not found: ' . $adminUserId);
        }
        return $adminUser;
    }
    
    private function getRequiredCityIds()
    {
        $allCities = $this->cityRepository->getAllCities(['id']);
        $cityIds = array_column($allCities, 'id');
        
        return array_diff($cityIds, explode(',', $this->option('ignore_city_ids')));
    }

    /**
     * Data source generator.
     *
     * @return mixed
     */
    private function getCustomerList()
    {
        $query = [
            'page' => 1,
            'fields' => 'customer_id,sales_id,' .
                'contact,mobile',
            'is_frozen' => 0,
            'project_status' => 1,
            'city_id' => implode(',', $this->getRequiredCityIds()),
            'sort_by' => [
                'customer_id' => -1,
            ],
        ];
        
        $count = 0;
        while (true) {
            try {
                $response = $this->customerRepository->getListByRetrieval($query, true);
                $list = array_get($response, 'list', []);
                if (empty($list)) {
                    break;
                }
                $count = $count + count($list);
                $total = array_get($response, 'pagination.total', 0);
                $query['page'] += 1;

                foreach ($list as $customer) {
                    $customerList = $this->customerRepository->getCustomersAsync(
                        [array_get($customer, 'customer_id')],
                        ['profile', 'account', 'project', 'contract', 'delivery']
                    );
                    $info = array_get($customerList, array_get($customer, 'customer_id'));

                    $customer['created_at'] = array_get($info, 'created_at');
                    $customer['business_manager_name'] = array_get($info, 'business_manager_name');
                    $customer['business_manager_mobile'] = array_get($info, 'business_manager_mobile');
                    
                    yield $customer;
                }

                if ($count >= $total) {
                    break;
                }
            } catch (\Exception $e) {
                $this->error('get customer list failed:'.$e->getMessage());
            }
        }
    }
    
    public function sendSms($customer)
    {
        $adminUser = $this->getAdminUser(array_get($customer, 'sales_id'));
        
        $stafferName = array_get($adminUser, 'nick');
        $stafferMobile = array_get($adminUser, 'mobile');
        
        if (empty($stafferName) || empty($stafferMobile)) {
            $this->error('Error: admin user nick or mobile is empty: ' . json_encode($adminUser));
        }
        
        $isValidAdminUser = false;
        if (array_get($adminUser, 'status.code') == config('admin_user.status.working.code')) {
            $isValidAdminUser = true;
        }
        
        $contacts = $this->getContacts($customer);
        foreach ($contacts as $mobile => $contactName) {
            if (Redis::hexists(self::SMS_PROMPT, $mobile)) {
                $this->info('Customer ' . array_get($customer, 'customer_id') .
                    ', mobile already send, mobile: ' . $mobile. ', send: ' . Redis::hget(self::SMS_PROMPT, $mobile));
                continue;
            }
            
            if (json_encode($contactName) === false) {
                $this->error('Customer ' . array_get($customer, 'customer_id') .
                    ', contact name error: ' . $contactName);
                continue;
            }
            
            $params = [
                'contact_name' => $contactName,
            ];
            if ($isValidAdminUser) {
                $params['sales'] = $stafferName . $stafferMobile;
            }
            $this->info('Customer ID: ' . array_get($customer, 'customer_id') .
                ', to ' . $mobile . ', body: ' . json_encode($params));
            
            if (!$this->option('dry_run')) {
                Log::info('Customer ID: ' . array_get($customer, 'customer_id') .
                    ', to ' . $mobile . ', body: ' . json_encode($params));
                Redis::hset(self::SMS_PROMPT, $mobile, Carbon::now()->toDateTimeString().'|customer');
                
                $this->smsRepository->sendSms(
                    $mobile,
                    $isValidAdminUser ? 'customer_clue.clue_prompt_contact_sales' : 'customer_clue.clue_prompt_common',
                    $params,
                    0
                );
            }
        }
    }
    
    private function getContacts($customer)
    {
        $contactList = [];
        
        if (!empty(array_get($customer, 'mobile'))) {
            $contactList[array_get($customer, 'mobile')] = array_get($customer, 'contact');
        }
        if (!empty(array_get($customer, 'business_manager_mobile'))) {
            $contactList[array_get($customer, 'business_manager_mobile')] = array_get($customer, 'business_manager_name');
        }
        
        foreach ($contactList as &$name) {
            if (empty($name)) {
                $name = '客户';
            } else {
                $name = mb_substr($name, 0, 1) . '总';
            }
        }
        
        return $contactList;
    }
    
    private function initLast()
    {
        $keys = Redis::keys('awakeSms_*');
        $this->info('Total keys: ' . count($keys));
        foreach ($keys as $key) {
            $time = Redis::get($key);
            
            $tmp = explode('_', $key);
            
            $this->info('Delete key: ' . $key. ', ' . $time);
            
            if (!$this->option('dry_run')) {
                Redis::hset(self::SMS_PROMPT, array_get($tmp, 1), $time);
                Redis::del($key);
            }
        }
    }
}
