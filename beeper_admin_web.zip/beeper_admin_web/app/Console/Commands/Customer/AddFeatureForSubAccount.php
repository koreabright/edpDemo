<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use YnRequest;
use App\Exceptions\BeeperException;

class AddFeatureForSubAccount extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'add_feature_for_sub_account {env} {permissionId}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '给历史数据子账号增加事故管理权限';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //
        $productionUserIds = [
            9426,
            9427,
            9435,
            9441,
            9482,
            9487,
            9488,
            9489,
            9538,
            9540,
            9618,
            9619,
            9758,
            9821,
            9860,
            9983,
            9984,
            9987,
            9994,
            10002,
            10003,
            10004,
            10043,
            10116,
            10126,
            10274,
            10275,
            10284,
            10308,
            10311,
            10367,
            10386,
            10406,
            10443,
            10711,
            10825,
            10990,
            10991,
            10992,
            11040,
            11217,
            11244,
            11247,
            11263,
            11282,
            11349,
            11350,
            11356,
            11367,
            11370,
            11371,
            11380,
            11381,
            11382,
            11394,
            11395,
            11403,
            11535,
            11543,
            11548,
            11566,
            11598,
            11642,
            11728,
            11752,
            11845,
            11863,
            11869,
            11887,
            11892,
            11893,
            11894,
            11938,
            11939,
            11998,
            12011,
            12012,
            12025,
            12026,
            12046,
            12073,
            12118,
            12119,
            12146,
            12148,
            12174,
            12186,
            12205,
            12206,
            12208,
            12214,
            12241,
            12243,
            12287,
            12380,
            12402,
            12410,
            12416,
        ];
        $stagingUserIds = [
            9426,
            9427,
            9435,
            9441,
            9482,
            9487,
            9488,
            9489,
            9538,
            9540,
            9618,
            9619,
            9758,
            9821,
            9860,
            9983,
            9984,
            9987,
            9994,
            10002,
            10003,
            10004,
            10043,
            10116,
            10126,
            10274,
            10275,
            10284,
            10308,
            10311,
            10367,
            10386,
            10406,
            10443,
            10711,
            10825,
            10912,
            10920,
            10934,
            10951,
        ];
        $testUserIds = [
            6731,
            6732,
            6733,
            6734,
            6737,
            6741,
            6742,
            6743,
            6744,
            6745,
            6746,
            6747,
            6748,
            6749,
            6750,
            6751,
            6753,
            6754,
            6755,
            6756,
            6759,
            6760,
            6761,
            6762,
            6763,
            6764,
            6765,
            6766,
            6767,
            6768,
            6769,
            6770,
            6771,
            6772,
            6773,
            6774,
            6775,
            6776,
            6777,
            6778,
            6779,
            6780,
            6781,
            6782,
            6783,
            6784,
            6785,
            6786,
            6787,
            6788,
            6789,
            6790,
            6791,
            6792,
            6794,
            6795,
            6796,
            6797,
            6798,
            6799,
            6800,
            6801,
            6806,
            6807,
            6808,
            6809,
            6810,
            6811,
            6812,
            6813,
            6814,
            6815,
            6816,
            6817,
            6818,
            6819,
            6820,
            6821,
            6822,
            6823,
            6824,
            6825,
            6826,
            6827,
            6828,
            6829,
            6830,
            6848,
            6849,
            6850,
            6851,
            6852,
            6853,
            6863,
            6923,
            6924,
            6931,
            6952,
            6955,
            6961,
            6965,
            6966,
            6968,
            6969,
            6970,
            6971,
            6972,
            6990,
            6992,
            6995,
            6999,
            7007,
            7008,
            7009,
            7044,
            7058,
            7102,
        ];
        $devUserIds = [
            6645,
            6647,
            6648,
            6649,
            6650,
            6652,
            6653,
            6654,
            6655,
            6656,
            6657,
            6658,
            6660,
            6661,
            6666,
            6667,
            6668,
        ];
        $this->info('开始啦!');
        Log::info('===========开始执行add_feature_for_sub_account============');
        $env = $this->argument('env');
        $permissionId = $this->argument('permissionId');
        if ($env === 'production') {
            $userIds = $productionUserIds;
        } elseif ($env === 'staging') {
            $userIds = $stagingUserIds;
        } elseif ($env === 'testing') {
            $userIds = $testUserIds;
        } elseif ($env === 'dev') {
            $userIds = $devUserIds;
        } else {
            throw new BeeperException('输入参数有误。');
        }
        if (empty($userIds)) {
            throw new BeeperException('userIds不能为空。');
        }
        $url = env('AUTH_SERVICE_API_HOST') . 'v1/admin/users/permissions';

        $params = [
            'client_id' => 2,
        ];
        $option = [
            'headers' => ['Authorization' => 'Bearer ' . env('AUTH_SERVICE_HACKED_TOKEN')],
        ];

        //先获取权限
        foreach ($userIds as $userId) {
            $params['user_id'] = $userId;
            YnRequest::addAsync('get', $userId, $url, $params, $option);
        }
        $result = YnRequest::runAsync();
        $newResult = [];
        foreach ($result as $key => $item) {
            $features = array_get(json_decode($item, true), 'info', []);
            $newResult[$key] = array_column($features, 'id');
        }

        //增加徐权限后保存
        foreach ($userIds as $userId) {
            $params['user_id'] = $userId;
            $newPermission = array_get($newResult, $userId, []);
            array_push($newPermission, (int)$permissionId);
            $newPermission = array_unique($newPermission);
            $params['enable_permission_ids'] = implode(',', $newPermission);
            YnRequest::addAsync('put', $userId, $url, $params, $option);
        }
        $result = YnRequest::runAsync();
        foreach ($result as $key => $value) {
            $code = array_get(json_decode($value, true), 'code', 1);
            if (0 !== (int)$code) {
                $mgs = 'user_id为' . $key . '的更新错误。msg: ' . array_get(json_decode($value, true), 'msg', '');
                $this->info($mgs);
                Log::info($mgs);
            }
        }
        $this->info('执行完毕!(没有输出错误信息则视为成功!)');
        Log::info('执行完毕!');
        return;
    }
}
