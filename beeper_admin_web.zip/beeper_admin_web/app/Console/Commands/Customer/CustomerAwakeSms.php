<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use App\Exceptions\BeeperException;
use App\Modules\Customer\Repositories\CustomerRepository;
use App\Modules\Customer\Repositories\AdminUserRepository;
use App\Modules\Customer\Repositories\CityRepository;
use App\Modules\Customer\Repositories\SmsRepository;
use App\Modules\Customer\Models\AdminUserModel;
use App\Repositories\WarehouseRepository;

use RequestsApi;
use Carbon\Carbon;
use Redis;

class CustomerAwakeSms extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer:customer_awake_sms {--dry_run=1}{--latest_trans_event_complete_date_end=}{--include_no_service=0}{--ignore_city_ids=}{--max_id=}{--skip=}{--limit=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '发送客户唤醒短信';

    protected $customerRepository;
    protected $adminUserModel;
    protected $cityRepository;
    protected $smsRepository;
    protected $warehouseRepository;
    
    protected $skipCount = 0;
    protected $runCount = 0;
    
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
        CustomerRepository $customerRepository,
        AdminUserModel $adminUserModel,
        CityRepository $cityRepository,
        SmsRepository $smsRepository,
        WarehouseRepository $warehouseRepository
    ) {
        $this->customerRepository = $customerRepository;
        $this->adminUserModel = $adminUserModel;
        $this->cityRepository = $cityRepository;
        $this->smsRepository = $smsRepository;
        $this->warehouseRepository = $warehouseRepository;
        
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('dry_run')) {
            $this->info('Dry run:');
        }
        RequestsApi::setCredential(false);
        
        $this->checkOptions();
        $customerList = $this->getCustomerList();

        foreach ($customerList as $customer) {
            if ($this->skipCount < $this->option('skip')) {
                $this->skipCount++;
                continue;
            } elseif ($this->skipCount == $this->option('skip') && $this->runCount == 0) {
                $this->info('Skip customers: ' . $this->skipCount);
            }
            
            if (!empty($this->option('max_id'))) {
                if (array_get($customer, 'customer_id') > $this->option('max_id')) {
                    $this->info('Skip customer ' . array_get($customer, 'customer_id')
                        . ', it is larger than option max_id: ' . $this->option('max_id'));
                    continue;
                }
            }
            
            if ($this->runCount >= $this->option('limit')) {
                $this->info('Run customers: ' . $this->runCount);
                break;
            }
            $this->runCount++;
            
            try {
                $this->sendSms($customer);
            } catch (\Exception $e) {
                $this->error('customer id : '.array_get($customer, 'customer_id') .
                    ' , info '.json_encode($customer).' failed: '.$e->getMessage() .
                    ', file: ' . $e->getFile() . ', line: ' . $e->getLine());
            }
        }
    }
    
    private function checkOptions()
    {
        if (strlen($this->option('latest_trans_event_complete_date_end')) != 19) {
            $this->error('latest_trans_event_complete_date_end: 错误的日期-时间格式');
            throw new BeeperException('latest_trans_event_complete_date_end: 错误的日期-时间格式');
        }
    }

    private function getAdminUser($adminUserId)
    {
        $adminUser = $this->adminUserModel->getAdminUserByIdWithoutCredential($adminUserId);
        if (empty($adminUser)) {
            throw new BeeperException('Admin user not found: ' . $adminUserId);
        }
        return $adminUser;
    }
    
    private function getRequiredCityIds()
    {
        $allCities = $this->cityRepository->getAllCities(['id']);
        $cityIds = array_column($allCities, 'id');
        
        return array_diff($cityIds, explode(',', $this->option('ignore_city_ids')));
    }

    /**
     * Data source generator.
     *
     * @return mixed
     */
    private function getCustomerList()
    {
        $query = [
            'page' => 1,
            'fields' => 'customer_id,sales_id,project_operation_mgr_id,' .
                'contract_archived,' .
                'contact,mobile',
            'is_frozen' => 0,
            'city_id' => implode(',', $this->getRequiredCityIds()),
            'sort_by' => [
                'customer_id' => -1,
            ],
        ];
        if (!$this->option('include_no_service')) {
            $query['latest_trans_event_complete_date_end'] = $this->option('latest_trans_event_complete_date_end');
        }
        
        $count = 0;
        while (true) {
            try {
                $response = $this->customerRepository->getListByRetrieval($query, true);
                $list = array_get($response, 'list', []);
                if (empty($list)) {
                    break;
                }
                $count = $count + count($list);
                $total = array_get($response, 'pagination.total', 0);
                $query['page'] += 1;

                foreach ($list as $customer) {
                    $customerList = $this->customerRepository->getCustomersAsync(
                        [array_get($customer, 'customer_id')],
                        ['profile', 'account', 'project', 'contract', 'delivery']
                    );
                    $info = array_get($customerList, array_get($customer, 'customer_id'));

                    $customer['created_at'] = array_get($info, 'created_at');
                    $customer['contract_end_date'] = array_get($info, 'contract_end_date');
                    $customer['business_manager_name'] = array_get($info, 'business_manager_name');
                    $customer['business_manager_mobile'] = array_get($info, 'business_manager_mobile');
                    $customer['latest_trans_event_complete_date'] = array_get(
                        $info,
                        'latest_trans_event_complete_date'
                    );
                    
                    if ($this->option('include_no_service')) {
                        if (!empty(array_get($customer, 'latest_trans_event_complete_date'))) {
                            if (Carbon::parse(array_get($customer, 'latest_trans_event_complete_date'))
                                > Carbon::parse($this->option('latest_trans_event_complete_date_end'))) {
                                continue;
                            }
                        } elseif (Carbon::parse(array_get($customer, 'created_at'))
                            > Carbon::parse($this->option('latest_trans_event_complete_date_end'))) {
                            continue;
                        }
                    }
                    
                    yield $customer;
                }

                if ($count >= $total) {
                    break;
                }
            } catch (\Exception $e) {
                $this->error('get customer list failed:'.$e->getMessage());
            }
        }
    }
    
    public function sendSms($customer)
    {
        $adminUser = [];
        if ($this->shouldSendToSales($customer)) {
            $adminUser = $this->getAdminUser(array_get($customer, 'sales_id'));
        } else {
            if (empty(array_get($customer, 'project_operation_mgr_id'))) {
                $this->error('Customer ' . array_get($customer, 'customer_id') . ' project operating mgr empty');
                return;
            } else {
                $adminUser = $this->getAdminUser(array_get($customer, 'project_operation_mgr_id'));
            }
        }
        $stafferName = array_get($adminUser, 'nick');
        $stafferMobile = array_get($adminUser, 'mobile');
        
        if (empty($stafferName) || empty($stafferMobile)) {
            $this->error('Error: admin user nick or mobile is empty: ' . json_encode($adminUser));
        }
        
        $contacts = $this->getContacts($customer);
        foreach ($contacts as $mobile => $contactName) {
            $key = 'awakeSms_'.$mobile.'_'.$stafferMobile;
            
            if (Redis::exists($key)) {
                $this->info('Customer ' . array_get($customer, 'customer_id') .
                    ', mobile already send, key: ' . $key . ', sent time: ' . Redis::get($key));
                continue;
            }
            if (!$this->option('dry_run')) {
                Redis::set($key, Carbon::now()->format('Y-m-d H:i:s'));
            }
            
            if (json_encode($contactName) === false) {
                $this->error('Customer ' . array_get($customer, 'customer_id') .
                    ', contact name error: ' . $contactName);
                continue;
            }
            
            $params = [
                'yn_staff_name' => $stafferName,
                'yn_staff_mobile' => $stafferMobile,
                'contact_name' => $contactName,
            ];
            $this->info('Customer ID: ' . array_get($customer, 'customer_id') .
                ', to ' . $mobile . ', body: ' . json_encode($params));
            
            if (!$this->option('dry_run')) {
                Log::info('Customer ID: ' . array_get($customer, 'customer_id') .
                    ', to ' . $mobile . ', body: ' . json_encode($params));
                $this->smsRepository->sendSms(
                    $mobile,
                    'customer.history_customer_awake',
                    $params,
                    0
                );
            }
        }
    }
    
    private function shouldSendToSales($customer)
    {
        if (!array_get($customer, 'contract_archived')) {
            return true;
        } elseif (Carbon::now() > Carbon::parse(array_get($customer, 'contract_end_date'))) {
            return true;
        }
        
        return false;
    }
    
    private function getContacts($customer)
    {
        $contactList = [];
        
        if (!empty(array_get($customer, 'mobile'))) {
            $contactList[array_get($customer, 'mobile')] = array_get($customer, 'contact');
        }
        if (!empty(array_get($customer, 'business_manager_mobile'))) {
            $contactList[array_get($customer, 'business_manager_mobile')] = array_get($customer, 'business_manager_name');
        }
        
        //Get warehouse list
        $params = [
            'customer_id' => array_get($customer, 'customer_id'),
            'page' => 1,
            'perpage' => config('warehouse.get_limit'),
        ];
        
        while (true) {
            $response = $this->warehouseRepository->getsSuggest($params);
            
            $wareHouses = array_get($response, 'list', []);
            if (empty($wareHouses)) {
                break;
            }
            
            foreach ($wareHouses as $wareHouse) {
                if (!empty(array_get($wareHouse, 'mobile'))) {
                    $contactList[array_get($wareHouse, 'mobile')] = array_get($wareHouse, 'contact');
                }
                
                foreach (array_get($wareHouse, 'backup_telphones', []) as $key => $tel) {
                    if (!empty($tel)) {
                        $name = array_get($wareHouse, 'backup_names.' . $key, '');
                        $contactList[$tel] = $name;
                    }
                }
            }
            
            $params['page']++;
            if ($params['page'] > array_get($response, 'pagination.total_pages')) {
                break;
            }
        }
        
        foreach ($contactList as $tel => &$name) {
            if (empty($name)) {
                $name = '客户';
            } else {
                $name = mb_substr($name, 0, 1) . '总';
            }
        }
        
        return $contactList;
    }
}
