<?php

namespace App\Console\Commands\Customer;

use GuzzleHttp\Psr7\UploadedFile;
use Illuminate\Console\Command;
use Log;
use Image;
use App\Exceptions\BeeperException;
use App\Services\ImageProcessService;
use App\Modules\Customer\Repositories\CompanyRepository;
use Symfony\Component\HttpFoundation\File\File;

class AddWaterMarkToHistoryCompany extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer_company:add_water_mark_to_history_company';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '给历史公司上的图片增加水印';

    protected $imgProcessService;
    protected $companyRepository;
    
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(ImageProcessService $imgProcessService, CompanyRepository $companyRepository)
    {
        $this->imgProcessService = $imgProcessService;
        $this->companyRepository = $companyRepository;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $companyList = $this->getCompanyList();

        $path = storage_path('imgProc');
        if (!file_exists($path)) {
            mkdir($path);
        }
        $tempImagePath = tempnam($path, 'tempImage');
        foreach ($companyList as $company) {
            try {
                $companyId = array_get($company, 'id', 0);
                $businessImagePath = array_get($company, 'business_license_image', '');
                $businessImageRawPath = array_get($company, 'business_license_image_raw', '');
                $openingImagePath = array_get($company, 'opening_license_image', '');
                $openingImageRawPath = array_get($company, 'opening_license_image_raw', '');

                $newBusinessUrl = '';
                $newOpeningUrl = '';
                if (!empty($businessImagePath) && empty($businessImageRawPath)) {
                    $newBusinessUrl = $this->processAndGetUrl($businessImagePath, $tempImagePath, $companyId, 'business_license_image');
                }
                if (!empty($openingImagePath) && empty($openingImageRawPath)) {
                    $newOpeningUrl = $this->processAndGetUrl($openingImagePath, $tempImagePath, $companyId, 'opening_license_image');
                }

                //更新公司信息
                $updateCompany = [];
                if (!empty($newBusinessUrl)) {
                    $updateCompany['business_license_image_raw'] = $businessImagePath;
                    $updateCompany['business_license_image'] = $newBusinessUrl;
                }
                if (!empty($newOpeningUrl)) {
                    $updateCompany['opening_license_image_raw'] = $openingImagePath;
                    $updateCompany['opening_license_image'] = $newOpeningUrl;
                }

                if (!empty($updateCompany)) {
                    $updateCompany['id'] = $companyId;
                    $updateCompany['operator_id'] = 0;
                    $this->companyRepository->updateCompanyByIdWithoutCredential($updateCompany);
                    $this->info("update company id ".$companyId." params ".json_encode($updateCompany));
                } else {
                    $this->info('update company id ' . $companyId . ': no need to update');
                }
            } catch (\Exception $e) {
                $this->error('company id : '.array_get($company, 'id') .
                    ' , info '.json_encode($company).' add water mark to history company failed: '.$e->getMessage());
            }
        }
        @unlink($tempImagePath);
    }

    protected function processAndGetUrl($businessImagePath, $tempImagePath, $companyId, $type)
    {
        $picContent = file_get_contents($businessImagePath);
        if (empty($picContent)) {
            throw new Exception('URL does not exists or file is empty!' . $businessImagePath);
        }

        $bytes = file_put_contents($tempImagePath, $picContent);
        if ($bytes <= 0) {
            throw new Exception('File write error: ' . $businessImagePath);
        }

        $file = new File($tempImagePath);
        $processCond = [];
        $processCond['file_path'] = $tempImagePath;
        $processCond['action'] = 'add_water_mark';
        $processCond['key'] = md5($businessImagePath);
        $processCond['ext_params']['orig_name'] = 'test';
        $processCond['ext_params']['mime_type'] = $file->getMimeType();
        $newBusinessUrl = $this->imgProcessService->doProcess($processCond);
        $this->info("company id".$companyId." add water mark for ".$type.", new url is ".$newBusinessUrl);

        $this->imgProcessService->clean($businessImagePath);

        return $newBusinessUrl;
    }

    /**
     * Data source generator.
     *
     * @return mixed
     */
    public function getCompanyList()
    {
        $query = ['page' => 1];
        $count = 0;
        while (true) {
            try {
                $response = $this->companyRepository->getCompanyListWithoutCredential($query);
                $list = array_get($response, 'list', []);
                if (empty($list)) {
                    break;
                }
                $count = $count + count($list);
                $total = array_get($response, 'pagination.total', 0);
                $query['page'] += 1;

                foreach ($list as $company) {
                    yield $company;
                }

                if ($count >= $total) {
                    break;
                }
            } catch (\Exception $e) {
                $this->error('get company list failed:'.$e->getMessage());
            }
        }
    }
}
