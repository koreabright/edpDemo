<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use App\Modules\Customer\Models\CustomerModel;
use App\Modules\Customer\Models\AdminUserModel;

class ChargeProjectOperationField extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer_profile:charge_project_operation_field';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '处理项目运营经理字段';

    protected $customerModel;
    protected $adminUserModel;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(CustomerModel $customerModel, AdminUserModel $adminUserModel)
    {
        $this->customerModel = $customerModel;
        $this->adminUserModel = $adminUserModel;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $customerList = $this->getCustomerList();
        foreach ($customerList as $customer) {
            try {
                $customerId = array_get($customer, 'customer_id', 0);
                $sopMgrId = array_get($customer, 'quality_mgr_id', 0);
                $adcId = array_get($customer, 'adcid', 0);
                $operationMgrId = array_get($customer, 'project_operation_mgr_id', 0);
                if ($operationMgrId == 0) {
                    if (!empty($sopMgrId) && $sopMgrId > 0) {
                        $sopMgr = $this->adminUserModel->getAdminUserByIdWithoutCredential($sopMgrId);
                        $roles = array_get($sopMgr, 'roles', []);
                        if (in_array('project_operation_mgr', $roles)) {
                            $params = ['query_customer_id' => $customerId, 'project_operation_mgr_id' => $sopMgrId];
                            $this->customerModel->updateCustomerInfoWithoutCredential($params);
                            Log::info('update customer id ' . $customerId . ' params is ' . json_encode($params));
                        } else {
                            $randAdmin = $this->adminUserModel->getAdminUserByRandomWithoutCredential(['adcids' => $adcId, 'roles' => 'project_operation_mgr', 'status' => 200]);
                            $randAdminId = array_get($randAdmin, 'admin_user_id', 0);
                            if ($randAdminId > 0) {
                                $params = ['query_customer_id' => $customerId, 'project_operation_mgr_id' => $randAdminId];
                                $this->customerModel->updateCustomerInfoWithoutCredential($params);
                                Log::info('update customer id ' . $customerId . ' params is ' . json_encode($params));
                            } else {
                                Log::info('customer id ' . $customerId . ' can not find any project operation mgr in adc id ' . $adcId);
                            }
                        }
                    } else {
                        $randAdmin = $this->adminUserModel->getAdminUserByRandomWithoutCredential(['adcids' => $adcId, 'roles' => 'project_operation_mgr', 'status' => 200]);
                        $randAdminId = array_get($randAdmin, 'admin_user_id', 0);
                        $randAdminNick = array_get($randAdmin, 'nick', '');
                        if ($randAdminId > 0) {
                            $params = ['query_customer_id' => $customerId, 'project_operation_mgr_id' => $randAdminId, 'quality_mgr_id' => $randAdminId, 'quality_mg' => $randAdminNick];
                            $this->customerModel->updateCustomerInfoWithoutCredential($params);
                            Log::info('update customer id ' . $customerId . ' params is ' . json_encode($params));
                        } else {
                            Log::info('customer id ' . $customerId . ' can not find any project operation mgr in adc id ' . $adcId);
                        }
                    }
                }
            } catch (\Exception $e) {
                $this->error('customer_id '.$customerId.' charge project operation field:'.$e->getMessage());
            }
        }
    }


    /**
     * Data source generator.
     *
     * @return mixed
     */
    public function getCustomerList()
    {
        $query = ['page' => 1];
        $count = 0;
        while (true) {
            try {
                $response = $this->customerModel->getCustomersWithoutCredential($query);
                $list = array_get($response, 'list', []);
                if (empty($list)) {
                    break;
                }
                $count = $count + count($list);
                $total = array_get($response, 'pagination.total', 0);
                $query['page'] += 1;

                foreach ($list as $company) {
                    yield $company;
                }

                if ($count >= $total) {
                    break;
                }
            } catch (\Exception $e) {
                $this->error('get customer list failed:'.$e->getMessage());
            }
        }
    }
}
