<?php

namespace App\Console\Commands\Customer;

use App\Exceptions\BeeperException;
use Illuminate\Console\Command;
use YnRequest;
use Log;

class InitialCreateTaskType extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'initial_create_task_type';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '初始化客户可创建的任务类型字段';

    /**
     * Create a new command instance.
     *
     *
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::custom('initial_create_task_type')->info('=========开始初始化客户可创建的任务类型字段=========');

        if (env('APP_ENV') == 'production') {
            $customerList = $this->productionData();
        }

        foreach ($customerList as $customer) {
            $this->update(
                $customer['customer_id'],
                $customer['create_task_type'],
                $customer['is_open_contract'],
                $customer['is_open_bailing_predict']
            );
            sleep(1);
        }

        Log::custom('initial_create_task_type')->info('=========初始化客户可创建的任务类型字段完成=========');
    }

    private function updateExistData()
    {
        $url = config('api.base_api.customer.get_setting_by_field');
        $perpage = 100;
        $page = 1;

        while (true) {
            $params = [
                'from' => config('app.app_from'),
                'is_open_dispatch_task' => 1,
                'perpage' => $perpage,
                'page' => $page,
                'fields' => 'customer_id'
            ];

            $response = json_decode(YnRequest::get($url, $params, []), true);

            if (array_get($response, 'code') != 0) {
                throw new BeeperException(array_get($response, 'msg', '获取客户信息发生错误'));
            }

            $customerList = array_get($response, 'info.list', []);
            foreach ($customerList as $customer) {
                $this->update($customer['customer_id'], [1,2,4,8], null, null);
            }

            if (array_get($response, 'info.pagination.total_pages', '') == $page) {
                break;
            }

            $page ++;
        }
    }

    private function stagingData()
    {
        return [
            ['customer_id' => 700, 'create_task_type' => [1,2,4,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
            ['customer_id' => 11489, 'create_task_type' => [4,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 0],
            ['customer_id' => 11506, 'create_task_type' => [1,2], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 11511, 'create_task_type' => [1,8], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 11551, 'create_task_type' => [2,4], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 3035, 'create_task_type' => [1,2], 'is_open_contract' => 1, 'is_open_bailing_predict' => 0],
        ];
    }

    private function testingData()
    {
        return [
            ['customer_id' => 131, 'create_task_type' => [1,2,4,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
            ['customer_id' => 171, 'create_task_type' => [1,4,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
            ['customer_id' => 279, 'create_task_type' => [4,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 0],
            ['customer_id' => 773, 'create_task_type' => [4,8], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 774, 'create_task_type' => [4], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 775, 'create_task_type' => [1,4], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 776, 'create_task_type' => [2,8], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 778, 'create_task_type' => [1,2], 'is_open_contract' => 1, 'is_open_bailing_predict' => 0],
            ['customer_id' => 784, 'create_task_type' => [1,2], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 801, 'create_task_type' => [2], 'is_open_contract' => 0, 'is_open_bailing_predict' => 0],
            ['customer_id' => 14086, 'create_task_type' => [1,2,4,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 0],
            ['customer_id' => 14087, 'create_task_type' => [1,2,4,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 0],
        ];
    }

    private function productionData()
    {
        return [
	        ['customer_id' => 1710, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 2479, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 2683, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 2964, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 3320, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 3365, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 3412, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 3555, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 3751, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 3814, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 4143, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 4317, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 4433, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 4647, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 5117, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 5265, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 5357, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 5448, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 5878, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 5974, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6095, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6160, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6211, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6236, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6314, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6402, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6741, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 6743, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 7229, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 7383, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 7401, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 7404, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 7450, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 7643, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 7829, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 8078, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 8106, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 8213, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 8708, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 8778, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 8888, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 8912, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9006, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9074, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9213, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9285, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9570, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9579, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9678, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9798, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9850, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9880, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9921, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 9987, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 10236, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 10547, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 10574, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 10592, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 10669, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 10978, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11216, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11461, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11462, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11529, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11626, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11688, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11717, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11756, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11764, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 11928, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12052, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12094, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12114, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12124, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12130, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12154, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12166, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12175, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12194, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12515, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12529, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12641, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12728, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12749, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12757, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12762, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12765, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12787, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12800, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12846, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12853, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12894, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12905, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12961, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12963, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 12988, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13018, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13022, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13042, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13044, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13088, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13094, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13101, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13158, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13173, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13189, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13251, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13254, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13261, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13275, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13279, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13300, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13318, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13322, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13326, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13334, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13359, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13365, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13375, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13406, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13417, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13418, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13491, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13501, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13505, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13515, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13553, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13555, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13556, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13561, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13571, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13586, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13598, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13601, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13608, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13615, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13619, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13638, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13709, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13718, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13728, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13734, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13738, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13756, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13759, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13767, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13787, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13802, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13803, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13814, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13827, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13859, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13860, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13861, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13875, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13886, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13887, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13892, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13894, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13897, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13911, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13915, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13918, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13961, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13974, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13986, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13991, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 13998, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 14023, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 14056, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 14057, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 14074, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 14076, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
	        ['customer_id' => 14098, 'create_task_type' => [1,8], 'is_open_contract' => 1, 'is_open_bailing_predict' => 1],
        ];
    }

    private function update($customerId, $type, $isOpenContract, $isOpenBailing)
    {
        $params = ['query_customer_id' => $customerId];
        $params['create_task_type'] = $type;
        if ($isOpenBailing !== null) {
            $params['is_open_bailing_predict'] = $isOpenBailing;
        }

        $url = config('api.base_api.customer.update_setting_by_id');
        $response = json_decode(YnRequest::post($url, $params, []), true);

        if (array_get($response, 'code') != 0) {
            $errorMsg = '更新客户信息错误: ' . array_get($response, 'msg') . ', request: ' . json_encode($params);
            Log::custom('initial_create_task_type')->error($errorMsg);
        } else {
            Log::custom('initial_create_task_type')->info('更新数据：' . json_encode($params));
        }

        if ($isOpenContract !== null) {
            $params = ['query_customer_id' => $customerId, 'is_open_contract' => $isOpenContract];

            $url = config('api.base_api.customer.update_profile_by_id');
            $response = json_decode(YnRequest::post($url, $params, []), true);

            if (array_get($response, 'code') != 0) {
                $errorMsg = '更新客户信息错误: ' . array_get($response, 'msg') . ', request: ' . json_encode($params);
                Log::custom('initial_create_task_type')->error($errorMsg);
            } else {
                Log::custom('initial_create_task_type')->info('更新数据：' . json_encode($params));
            }
        }
    }
}
