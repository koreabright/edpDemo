<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use App\Exceptions\BeeperException;

use App\Modules\CustomerClue\Repositories\ClueRepository;
use App\Modules\Customer\Repositories\CityRepository;
use App\Modules\Customer\Repositories\SmsRepository;
use App\Modules\Customer\Models\AdminUserModel;

use RequestsApi;
use Carbon\Carbon;
use Redis;

class CluePromptSms extends Command
{
    const SMS_PROMPT = 'sms_prompt';
    
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer:clue_prompt_sms {--dry_run=1}{--ignore_city_ids=}{--max_id=}{--skip=}{--limit=}{--source_from=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '发送线索促进开户短信';

    protected $clueRepository;
    protected $adminUserModel;
    protected $cityRepository;
    protected $smsRepository;
    
    protected $skipCount = 0;
    protected $runCount = 0;
    
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
        AdminUserModel $adminUserModel,
        CityRepository $cityRepository,
        ClueRepository $clueRepository,
        SmsRepository $smsRepository
    ) {
        $this->clueRepository = $clueRepository;
        $this->adminUserModel = $adminUserModel;
        $this->cityRepository = $cityRepository;
        $this->smsRepository = $smsRepository;
        
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('dry_run')) {
            $this->info('Dry run:');
        }
        
        RequestsApi::setCredential(false);
        
        $clueList = $this->getClueList();

        foreach ($clueList as $clue) {
            if ($this->skipCount < $this->option('skip')) {
                $this->skipCount++;
                continue;
            } elseif ($this->skipCount == $this->option('skip') && $this->runCount == 0) {
                $this->info('Skip clue: ' . $this->skipCount);
            }
            
            if (!empty($this->option('max_id'))) {
                if (array_get($clue, 'id') > $this->option('max_id')) {
                    $this->info('Skip clue ' . array_get($clue, 'id')
                        . ', it is larger than option max_id: ' . $this->option('max_id'));
                    continue;
                }
            }
            
            if ($this->runCount >= $this->option('limit')) {
                $this->info('Run clues: ' . $this->runCount);
                break;
            }
            $this->runCount++;
            
            try {
                $this->sendSms($clue);
            } catch (\Exception $e) {
                $this->error('clue id : '.array_get($clue, 'id') .
                    ' , info '.json_encode($clue).' failed: '.$e->getMessage() .
                    ', file: ' . $e->getFile() . ', line: ' . $e->getLine());
            }
        }
    }
    
    private function getAdminUser($adminUserId)
    {
        $adminUser = $this->adminUserModel->getAdminUserByIdWithoutCredential($adminUserId);
        if (empty($adminUser)) {
            throw new BeeperException('Admin user not found: ' . $adminUserId);
        }
        return $adminUser;
    }

    /**
     * Data source generator.
     *
     * @return mixed
     */
    private function getClueList()
    {
        $query = [
            'page' => 1,
            'status' => [
                config('customer_clue.clue.clue_status.assigned.code'),
                config('customer_clue.clue.clue_status.active.code'),
                config('customer_clue.clue.clue_status.account_assigned.code'),
            ],
        ];
        if ($this->option('source_from') > 0) {
            $query['source_from'] = $this->option('source_from');
        }
        
        $count = 0;
        while (true) {
            try {
                $response = $this->clueRepository->getClueList($query);
                $list = array_get($response, 'list', []);
                if (empty($list)) {
                    break;
                }
                $count = $count + count($list);
                $total = array_get($response, 'count', 0);
                $query['page'] += 1;

                foreach ($list as $clue) {
                    yield $clue;
                }

                if ($count >= $total) {
                    break;
                }
            } catch (\Exception $e) {
                $this->error('get clue list failed:'.$e->getMessage());
            }
        }
    }
    
    public function sendSms($clue)
    {
        $adminUser = $this->getAdminUser(array_get($clue, 'charge_admin_user_id'));
        
        $stafferName = array_get($adminUser, 'nick');
        $stafferMobile = array_get($adminUser, 'mobile');
        
        $isValidAdminUser = false;
        if (empty($stafferName) || empty($stafferMobile)) {
            $this->error('Admin user nick or mobile is empty: ' . json_encode($adminUser));
            $isValidAdminUser = false;
        } elseif (array_get($adminUser, 'status.code') == config('admin_user.status.working.code')) {
            $isValidAdminUser = true;
        }
        
        $contacts = $this->getContacts($clue);
        foreach ($contacts as $mobile => $contactName) {
            if (Redis::hexists(self::SMS_PROMPT, $mobile)) {
                $this->info('Clue ' . array_get($clue, 'id') .
                    ', mobile already send, mobile: ' . $mobile. ', send: ' . Redis::hget(self::SMS_PROMPT, $mobile));
                continue;
            }
            
            if (json_encode($contactName) === false) {
                $this->error('Clue ' . array_get($clue, 'id') .
                    ', contact name error: ' . $contactName);
                continue;
            }
            
            $params = [
                'contact_name' => $contactName,
            ];
            if ($isValidAdminUser) {
                $params['sales'] = $stafferName . $stafferMobile;
            }
            $this->info('Clue ID: ' . array_get($clue, 'id') .
                ', to ' . $mobile . ', body: ' . json_encode($params));
            
            if (!$this->option('dry_run')) {
                Log::info('Clue ID: ' . array_get($clue, 'customer_id') .
                    ', to ' . $mobile . ', body: ' . json_encode($params));
                Redis::hset(self::SMS_PROMPT, $mobile, Carbon::now()->toDateTimeString().'|clue');
                
                $this->smsRepository->sendSms(
                    $mobile,
                    $isValidAdminUser ? 'customer_clue.clue_prompt_contact_sales' : 'customer_clue.clue_prompt_common',
                    $params,
                    0
                );
            }
        }
    }
    
    private function getContacts($clue)
    {
        $contactList = [];
        
        $contactList[array_get($clue, 'mobile')] = array_get($clue, 'name');
        
        foreach ($contactList as &$name) {
            if (empty($name)) {
                $name = '客户';
            } else {
                $name = mb_substr($name, 0, 1) . '总';
            }
        }
        
        return $contactList;
    }
}
