<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use App\Modules\Customer\Models\CustomerModel;
use App\Modules\Customer\Models\CustomerEntityModel;

class UpdateCustomerCompanyName extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer_profile:update_customer_company_name';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '更新客户的公司全称';

    protected $customerModel;
    protected $customerEntityModel;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(CustomerModel $customerModel, CustomerEntityModel $customerEntityModel)
    {
        $this->customerModel = $customerModel;
        $this->customerEntityModel = $customerEntityModel;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $customers = $this->customerModel->getCustomersByRetrievalWithoutCredential(['perpage' => 1000, 'created_at_start' => '2017-07-20 00:00:00', 'field' => 'company_name']);
        $customerInfo = array_get($customers, 'list', []);
        $customerIds = array_column($customerInfo, 'customer_id');
        foreach ($customerIds as $customerId) {
            try {
                $accountInfo = $this->customerModel->getCustomersWithoutCredential(['customer_id' => $customerId], 'account');
                $accountInfo = array_get($accountInfo, 'list.0');
                $companyId = array_get($accountInfo, 'company_id', 0);
                $oldCompanyName = array_get($accountInfo, 'company_name', '');
                if($companyId > 0 && (strpos($oldCompanyName, '(') !== false)){
                    $companyInfo = $this->customerEntityModel->getCompanyByIdWithoutCredential($companyId);
                    $companyName = array_get($companyInfo, 'name');
                    //包含字符串"(",则进行处理
                    {
                        $params = ['query_customer_id' => $customerId, 'company_name' => $companyName];
                        $this->customerModel->updateCustomerInfoWithoutCredential($params, 'account');
                        Log::info('update customer id ' . $customerId . ' company name is ' . $companyName);
                    }

                }
            } catch (\Exception $e) {
                $this->error('customer_id '.$customerId.' update customer company name failed:'.$e->getMessage());
            }
        }
    }
}
