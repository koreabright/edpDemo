<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use App\Exceptions\BeeperException;
use App\Modules\Customer\Repositories\SmsRepository;

use RequestsApi;
use Carbon\Carbon;
use Redis;

class SpiderCluePromptSms extends Command
{
    const SMS_PROMPT = 'sms_prompt';
    
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer:spider_clue_prompt_sms {--dry_run=1}{--ignore_city_ids=}{--min_id=}{--skip=}{--limit=}{--file=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '发送爬虫线索促进开户短信';

    protected $smsRepository;
    
    protected $skipCount = 0;
    protected $runCount = 0;
    
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
        SmsRepository $smsRepository
    ) {
        $this->smsRepository = $smsRepository;
        
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('dry_run')) {
            $this->info('Dry run:');
        }
        
        if (empty($this->option('file')) || !file_exists($this->option('file'))) {
            $this->error('File not set or not exists!');
            return;
        }
        
        RequestsApi::setCredential(false);
        
        $clueList = $this->getClueList();

        foreach ($clueList as $clue) {
            if ($this->skipCount < $this->option('skip')) {
                $this->skipCount++;
                continue;
            } elseif ($this->skipCount == $this->option('skip') && $this->runCount == 0) {
                $this->info('Skip clue: ' . $this->skipCount);
            }

            if (!empty($this->option('min_id'))) {
                if (array_get($clue, 'id') < $this->option('min_id')) {
                    $this->info('Skip clue ' . array_get($clue, 'id')
                        . ', it is larger than option max_id: ' . $this->option('min_id'));
                    continue;
                }
            }
            
            if ($this->runCount >= $this->option('limit')) {
                $this->info('Run clues: ' . $this->runCount);
                break;
            }
            $this->runCount++;
            
            try {
                $this->sendSms($clue);
            } catch (\Exception $e) {
                $this->error('clue id : '.array_get($clue, 'id') .
                    ' , info '.json_encode($clue).' failed: '.$e->getMessage() .
                    ', file: ' . $e->getFile() . ', line: ' . $e->getLine());
            }
        }
    }

    /**
     * Data source generator.
     *
     * @return mixed
     */
    private function getClueList()
    {
        $file = fopen($this->option('file'), 'r');
        
        $line = 0;
        while (($data = fgetcsv($file) ) !== false) {
            $line++;
            if ($line > 1) {
                for ($col = 0; $col < 12; $col+=2) {
                    $name = array_get($data, 0 + $col);
                    $mobile = array_get($data, 1 + $col);
                    
                    if (!empty($mobile)) {
                        $clue = [
                            'id' => $line,
                            'name' => trim($name),
                            'mobile' => trim($mobile),
                        ];
                        yield $clue;
                    }
                }
            }
        }
        
        fclose($file);
    }
    
    public function sendSms($clue)
    {
        $contacts = $this->getContacts($clue);
        foreach ($contacts as $mobile => $contactName) {
            if (Redis::hexists(self::SMS_PROMPT, $mobile)) {
                $this->info('Clue ' . array_get($clue, 'id') .
                    ', mobile already send, mobile: ' . $mobile. ', send: ' . Redis::hget(self::SMS_PROMPT, $mobile));
                continue;
            }
            
            if (json_encode($contactName) === false) {
                $this->error('Clue ' . array_get($clue, 'id') .
                    ', contact name error: ' . $contactName);
                continue;
            }
            
            $params = [
                'contact_name' => $contactName,
            ];
            $this->info('Clue ID: ' . array_get($clue, 'id') .
                ', to ' . $mobile . ', body: ' . json_encode($params));
            
            if (!$this->option('dry_run')) {
                Log::info('Clue ID: ' . array_get($clue, 'customer_id') .
                    ', to ' . $mobile . ', body: ' . json_encode($params));
                Redis::hset(self::SMS_PROMPT, $mobile, Carbon::now()->toDateTimeString().'|spider');
                
                $this->smsRepository->sendSms(
                    $mobile,
                    'customer_clue.clue_prompt_common',
                    $params,
                    0
                );
            }
        }
    }
    
    private function getContacts($clue)
    {
        $contactList = [];
        
        $mobile = $this->parseMobile(array_get($clue, 'mobile'));
        if (empty($mobile)) {
            return $contactList;
        }
        
        $contactList[$mobile] = array_get($clue, 'name');
        
        foreach ($contactList as &$name) {
            $firstLetter = substr($name, 0, 1);
            if (empty($name) || ord($firstLetter) <= 127) {
                $name = '客户';
            } else {
                $name = mb_substr($name, 0, 1) . '总';
            }
        }
        
        return $contactList;
    }
    
    private function parseMobile($mobile)
    {
        if (substr($mobile, 0, 1) == '-') {
            $mobile = substr($mobile, 1);
        }

        if (strlen($mobile) != 11 || !is_numeric($mobile)) {
            $this->error('Phone no ' . $mobile . ' format error');
            return '';
        }

        return $mobile;
    }
}
