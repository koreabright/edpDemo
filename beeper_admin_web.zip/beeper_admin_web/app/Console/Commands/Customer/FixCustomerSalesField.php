<?php

namespace App\Console\Commands\Customer;

use Illuminate\Console\Command;
use Log;
use App\Exceptions\BeeperException;
use App\Modules\Customer\Repositories\CustomerRepository;
use App\Modules\Customer\Models\AdminUserModel;
use RequestsApi;

class FixCustomerSalesField extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'customer:fix_customer_sales_field {--dry_run=1}{--min_created_at=}{--id=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '修复mongodb客户上sales字段';

    protected $customerRepository;
    protected $adminUserModel;
    
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(CustomerRepository $customerRepository, AdminUserModel $adminUserModel)
    {
        $this->customerRepository = $customerRepository;
        $this->adminUserModel = $adminUserModel;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('dry_run')) {
            $this->info('Dry run:');
        } else {
            RequestsApi::setCredential(false);
        }
        $customerList = $this->getCustomerList();

        foreach ($customerList as $customer) {
            try {
                $customerId = array_get($customer, 'customer_id', 0);
                $sales = array_get($customer, 'sales', '');

                $needUpdate = true;
                if ($this->option('min_created_at') && array_get($customer, 'created_at') < $this->option('min_created_at')) {
                    $needUpdate = false;
                }else if ($this->option('id') && !in_array($customerId, explode(',', $this->option('id')))) {
                    $needUpdate = false;
                }
                
                //更新客户信息
                $updateCustomer = [];
                if ($needUpdate) {
                    $updateCustomer['sales'] = $this->getAdminUserName(array_get($customer, 'sales_id'));
                } else {
                    continue;
                }
                
                if (!empty($updateCustomer)) {
                    $updateCustomer['query_customer_id'] = $customerId;
                    $updateCustomer['operator_id'] = 0;
                    if (!$this->option('dry_run')) {
                        $this->customerRepository->updates($updateCustomer, 'profile');
                    }
                    $this->info("update customer id ".$customerId." params ".json_encode($updateCustomer));
                } else {
                    $this->info('update customer id ' . $customerId . ': no need to update');
                }
            } catch (\Exception $e) {
                $this->error('customer id : '.array_get($customer, 'customer_id') .
                    ' , info '.json_encode($customer).' failed: '.$e->getMessage() .
                    ', file: ' . $e->getFile() . ', line: ' . $e->getLine());
            }
        }
    }

    public function getAdminUserName($adminUserId)
    {
        $adminUser = $this->adminUserModel->getAdminUserByIdWithoutCredential($adminUserId);
        $adminUserNick = array_get($adminUser, 'nick');
        if (empty($adminUserNick)) {
            throw new BeeperException('Admin user not found: ' . $adminUserId);
        }
        return $adminUserNick;
    }

    /**
     * Data source generator.
     *
     * @return mixed
     */
    public function getCustomerList()
    {
        $query = ['page' => 1, 'fields' => 'customer_id,sales_id'];
        $count = 0;
        while (true) {
            try {
                $response = $this->customerRepository->getListByRetrieval($query, true);
                $list = array_get($response, 'list', []);
                if (empty($list)) {
                    break;
                }
                $count = $count + count($list);
                $total = array_get($response, 'pagination.total', 0);
                $query['page'] += 1;

                foreach ($list as $customer) {
                    yield $customer;
                }

                if ($count >= $total) {
                    break;
                }
            } catch (\Exception $e) {
                $this->error('get customer list failed:'.$e->getMessage());
            }
        }
    }
}
