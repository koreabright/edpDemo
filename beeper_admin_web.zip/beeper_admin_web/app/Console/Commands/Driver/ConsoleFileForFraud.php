<?php

namespace App\Console\Commands\Driver;

use YnRequest;
use Log;
use JoinLibrary;
use Carbon\Carbon;
use Illuminate\Console\Command;
use App\Exceptions\BeeperException;
use App\Services\ExportJobService;
use Yunniao\Utils\Request\Exceptions\RequestException;

class ConsoleFileForFraud extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'driver:export_csv_file_for_fraud {adminIds} {start?} {end?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'console driver fraud record';

    /**
     * @var string
     */
    private $yesterday;

    /**
     * @var string start of previous day
     */
    private $dateStart;

    /**
     * @var string end of previous day
     */
    private $dateEnd;

    /**
     * @var string path of output
     */
    private $outputPath;

    /**
     * @var array header of the file
     */
    private $header = [
        '出车记录编号',
        '任务编号',
        '客户编号',
        '客户名称',
        '客户所属城市',
        '客户所属管理区',
        '仓名称',
        '客户创建时间',
        '项目类型',
        '开跑日期',
        '最近出车日期',
        '选司机操作平台',
        '选司机操作设备',
        '司机创建时间',
        '司机编号',
        '司机姓名',
        '司机手机号',
        '出车时间',
        '司机签到时间',
        '司机离仓时间',
        '司机配送完成时间',
        '是否加跑',
        '点击加跑时间',
        '是否补完成',
        '描述',
        '司机备用电话',
        '车型',
        '车牌',
        '所属车队',
        '客服经理',
        '岗控合伙人',
        '运作经理',
        '运作主管（手机）',
        '司机所属拓展经理',
        '客户基础运力价格',
        '客户基础运力价格(不含税)',
        '提成价格',
        '提成价格(不含税)',
        '客户总价格',
        '司机基础运力价格',
        '司机提成运费',
        '司机补贴总额',
        '司机补贴明细',
        '司机管理费总额',
        '司机保障费总额',
        '司机抽佣总额',
        '司机总价格',
        '付款方式',
        '报价人数',
        'sop服务',
        '任务配送里程最小值',
        '任务配送里程最大值',
        '司机类型',
        '轨迹长度(km)',
        '竞标时间',
    ];

    /**
     * @var array 可下载用户id
     */
    private $adminIds = [];

    /**
     * @var int record total
     */
    private $recordTotal = 0;

    /**
     * @var int 成功记录条数
     */
    private $successCount = 0;

    /**
     * @var int 失败记录条数
     */
    private $failCount = 0;

    /**
     * @const int 重试次数
     */
    const RETRY_TIMES = 1;

    /**
     * @const int 请求阈值，并且失败数超出该值，认为任务失败
     */
    const THRESHOLD = 20;

    /**
     * ConsoleFileForFraud constructor.
     */
    public function __construct()
    {
        parent::__construct();

        //initialize date of yesterday
        $this->yesterday = Carbon::yesterday()->toDateString();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     * @param ExportJobService $exportJob
     */
    public function handle(ExportJobService $exportJob)
    {
        //initialize
        $this->init();

        $exportType = config('export_job.file_format.csv.code');
        $jobIds = [];
        foreach ($this->adminIds as $v) {
            $job = $exportJob->createPushJob(
                '下载：检察中心判定有无罪的出车列表' . $this->dateStart . ' ~ ' . $this->dateEnd,
                '下载：检察中心判定有无罪的出车列表' . $this->dateStart . ' ~ ' . $this->dateEnd . '.csv',
                $exportType,
                $v
            );

            $jobIds[] = array_get($job, 'id');
        }

        $isSuccess = true;
        try {
            //写文件
            $this->writeFile();
        } catch (\Exception $e) {
            foreach ($jobIds as $v) {
                $exportJob->setJobFailed($v, $e->getMessage());
            }

            $isSuccess = false;
            Log::error(
                'console driver fraud record error,' .
                'errorMsg: ' . $e->getMessage()
            );
        }

        if ($isSuccess) {
            foreach ($jobIds as $v) {
                $exportJob->uploadFile(
                    $v,
                    $this->outputPath,
                    ['total_row' => $this->successCount],
                    false
                );
            }
        }

        Log::info(
            $this->dateStart . ' - ' . $this->dateEnd . ' console driver fraud record over,' .
            'total: ' . $this->recordTotal . ', ' .
            'success: ' . $this->successCount . ', ' .
            'fail: ' . ($this->failCount > $this->recordTotal ? $this->recordTotal : $this->failCount)
        );

        @unlink($this->outputPath);
    }

    /**
     * initialize some var
     */
    private function init()
    {
        //get the arguments
        $start = $this->argument('start');
        $end = $this->argument('end');

        //initialize the start and end of a day
        $this->dateStart = ($start ? $start : $this->yesterday) . ' 00:00:00';
        $this->dateEnd = ($end ? $end : $this->yesterday) . ' 23:59:59';

        //initialize the admin ids that can download the file
        $this->adminIds = explode(',', $this->argument('adminIds'));
    }

    /**
     * Write file.
     *
     * @throws BeeperException
     */
    private function writeFile()
    {
        //生成数据
        $eventList = $this->dataGenerator();

        //生成临时文件
        $this->outputPath = tempnam(storage_path('app'), 'driver_fraud');

        //打开临时文件并返回句柄
        $handle = fopen($this->outputPath, 'a+');

        //BOM
        fwrite($handle, chr(0xEF).chr(0xBB).chr(0xBF));

        //写入文件头信息
        fputcsv($handle, $this->header);

        foreach ($eventList as $item) {
            foreach ($item as $v) {
                //司机竞标信息
                $bidInfo = $this->getBidInfo(array_get($v, 'trans_task_id'), array_get($v, 'trans_driver_bid_id'));

                $tmp = [
                    array_get($v, 'id'),
                    array_get($v, 'trans_task_id'),
                    array_get($v, 'customer_id'),
                    array_get($v, 'customerInfo.name'),
                    array_get($v, 'customerInfo.city'),
                    array_get($v, 'adcInfo'),
                    array_get($v, 'warehouseInfo.name'),
                    date('Y-m-d H:i:s', array_get($v, 'customerInfo.cts') / 1000),
                    array_get($v, 'customerInfo.pt') == 1 ? '封装' : '自助',
                    array_get($v, 'customerInfo.service_start'),
                    array_get($v, 'customerInfo.latest_trans_event_complete_date'),
                    array_get($bidInfo, 'sourceDisplay'),
                    $this->getOperatingTerminal(array_get($v, 'trans_task_id')),
                    date('Y-m-d H:i:s', array_get($v, 'driverInfo.cts') / 1000),
                    array_get($v, 'driver_id'),
                    array_get($v, 'driverInfo.name'),
                    '="' . array_get($v, 'driverInfo.mobile') . '"',
                    array_get($v, 'work_time'),
                    array_get($v, 'check_in_time'),
                    array_get($v, 'departure_time'),
                    array_get($v, 'complete_time'),
                    array_get($v, 'is_addition'),
                    array_get($v, 'is_addition') ? array_get($v, 'created_at') : '',
                    array_get($v, 'is_supplement') ? '是' : '否',
                    array_get($v, 'comment'),
                    '="' . implode(' ', array_get($v, 'driverInfo.tels', [])) . '"',
                    array_get($v, 'carTypeInfo.name'),
                    array_get($v, 'driverInfo.car_num'),
                    array_get($v, 'carTeamInfo.show_info'),
                    array_get($v, 'salesInfo.nick'),
                    array_get($v, 'bidInfo.nick'),
                    array_get($v, 'sopMgrInfo.nick'),
                    array_get($v, 'fccInfo.name_with_mobile'),
                    array_get($v, 'ddInfo.nick'),
                    array_get($v, 'cprice_per_day_with_tax_display'),
                    array_get($v, 'cprice_per_day_display'),
                    round((array_get($v, 'customer_bonus_charge') + array_get($v, 'customer_bonus_charge_tax')) / 100, 2),
                    array_get($v, 'customer_bonus_charge_display'),
                    array_get($v, 'cprice_total_with_tax_display'),
                    array_get($v, 'dprice_per_day_display'),
                    array_get($v, 'driver_bonus_money_display'),
                    array_get($v, 'dprice_subsidy_total_display'),
                    array_get($v, 'subsidies_to_driver_display'),
                    array_get($v, 'total_commission_money_display'),
                    array_get($v, 'driver_insurance_money_display'),
                    array_get($v, 'commission_money_display'),
                    array_get($v, 'dprice_total_display'),
                    array_get($v, 'first_pay_money_display'),
                    array_get($bidInfo, 'count', 0),
                    array_get($v, 'have_sop') ? 'SOP(已实施)' : 'SOP(未实施)',
                    array_get($v, 'trans_task_info.distance_min'),
                    array_get($v, 'trans_task_info.distance_max'),
                    array_get($v, 'task_type_display'),
                    $this->getMileage(
                        array_get($v, 'id'),
                        array_get($v, 'trans_task_id'),
                        array_get($v, 'customer_id'),
                        array_get($v, 'driver_id')
                    ),
                    array_get($bidInfo, 'createdAt', '')
                ];

                $result = fputcsv($handle, $tmp);

                if ($result !== false) {
                    $this->successCount++;
                }
            }
        }

        $this->failCount = $this->failCount > $this->recordTotal ? $this->recordTotal : $this->failCount;
        //写入统计数据
        fputcsv($handle, [
            '共计: ' . $this->recordTotal . ' 条',
            '成功: ' . $this->successCount . ' 条',
            '失败: ' . $this->failCount . ' 条'
        ]);

        fclose($handle);

        //如果错误数大于等于阈值则认为任务失败
        if ($this->failCount >= self::THRESHOLD) {
            throw new BeeperException('列表读取错误' . $this->failCount . '条，任务执行失败');
        }
    }

    /**
     * 生成数据
     *
     * @return array
     */
    private function dataGenerator()
    {
        $params['page'] = 1;
        $params['perpage'] = self::THRESHOLD;
        $params['is_with_all_event'] = 1;
        $params['is_with_deleted'] = 1;
        $params['status'] = 900;
        $params['complete_date_start'] = $this->dateStart;
        $params['complete_date_end'] = $this->dateEnd;

        $count = $times = 0;
        while (true) {
            try {
                $response = json_decode(YnRequest::get(config('api.tf_api.event.list'), $params, []), true);
                if (array_get($response, 'code') != 0) {
                    throw new RequestException(
                        'Get event list error: ' . array_get($response, 'msg'),
                        array_get($response, 'code')
                    );
                }

                $list = array_get($response, 'info.list', []);
                if (empty($list)) {
                    break;
                }

                $params['page']++;

                $count += count($list);
                $total = $this->recordTotal = array_get($response, 'info.count', 0);

                $list = $this->assemblyInfo($list);

                yield $list;

                if ($count >= $total) {
                    break;
                }
            } catch (RequestException $e) {
                $times++;
                if ($times > self::RETRY_TIMES) {
                    $this->failCount += $params['perpage'];
                    Log::error(
                        'request url error,' .
                        'currentPage: ' . $params['page'] .
                        'perPage: ' . $params['perpage'] .
                        'params: ' . json_encode($params) . ', ' .
                        'errorMsg: ' . $e->getMessage()
                    );
                    $params['page']++;
                    $times = 0;
                }
            } catch (BeeperException $e) {
                $this->failCount += $params['perpage'];
                Log::error(
                    'assembly info error,' .
                    'currentPage: ' . $params['page'] .
                    'perPage: ' . $params['perpage'] .
                    'errorMsg: ' . $e->getMessage()
                );
            }
        }
    }

    /**
     * Assembly information
     *
     * @param array $data
     * @return arrray
     * @throws \Exception
     */
    private function assemblyInfo($data)
    {
        //所需仓信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'warehouseInfo',
                    config('api.base_api.warehouse.get_all_by_wid'),
                    'warehouse_id',
                    'wid',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['wid','name']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需司机信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'driverInfo',
                    config('api.base_api.driver.get_all_by_id'),
                    'driver_id',
                    'did',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['did','name','mobile','tels','cts','car_num']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需车型信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'carTypeInfo',
                    config('api.base_api.car_type.gets'),
                    'car_id',
                    'ctid',
                    'ctids',
                    'info.list',
                    'get',
                    ['fields' => 'ctid,name'],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需车队信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'carTeamInfo',
                    config('api.base_api.car_team.get_car_team_by_ids'),
                    'car_team_id',
                    'ctid',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['ctid','show_info']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需销售信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'salesInfo',
                    config('api.base_api.admin_user.get_join_admin_users_by_ids'),
                    'sales_id',
                    '_id',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['_id','nick']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需岗控合伙人信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'bidInfo',
                    config('api.base_api.admin_user.get_join_admin_users_by_ids'),
                    'bid_mgr_id',
                    '_id',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['_id','nick']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需增值服务相关运作经理信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'sopMgrInfo',
                    config('api.base_api.admin_user.get_join_admin_users_by_ids'),
                    'sop_mgr_id',
                    '_id',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['_id','nick']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需运作主管信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'fccInfo',
                    config('api.base_api.fcc.list_all'),
                    'fcc_id',
                    'fccid',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['fccid','name_with_mobile']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需拓展经理信息
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'ddInfo',
                    config('api.base_api.admin_user.get_join_admin_users_by_ids'),
                    'dd_id',
                    '_id',
                    'ids',
                    'info',
                    'get',
                    ['fields' => ['_id','nick']],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //配送里程最小值和最大值
        $count = 0;
        while (true) {
            try {
                $data = JoinLibrary::apiJoin(
                    $data,
                    'trans_task_info',
                    config('api.trans_service_api.task.list'),
                    'trans_task_id',
                    'id',
                    'trans_task_id',
                    'info.list',
                    'get',
                    ['perpage' => count($data)],
                    false
                );
            } catch (\Exception $e) {
                $count++;
                if ($count <= self::RETRY_TIMES) {
                    continue;
                }
                throw $e;
            }
            break;
        }

        //所需客户信息
        $data = $this->getCustomer($data);

        //所需管理区信息
        $data = $this->getAdc($data);

        return $data;
    }

    /**
     * Get customer's information by customer id
     *
     * @param array $data
     * @return array
     * @throws BeeperException
     */
    private function getCustomer($data)
    {
        $customerIds = array_column($data, 'customer_id');
        $params = [
            'fields' => 'cuid name city pt cts service_start latest_trans_event_complete_date',
            'where' => [
                'cuid' => [
                    '$in' => array_flip(array_flip($customerIds)) //去重处理
                ]
            ]
        ];

        $customer = [];
        $count = 0;
        while (true) {
            try {
                $customer = json_decode(YnRequest::get(config('api.base_api.customer.get_customers_by_ids'), $params, []), true);
                if (array_get($customer, 'code') != 0) {
                    throw new BeeperException('getCustomer : ' . array_get($customer, 'msg'));
                }
                break;
            } catch (\Exception $e) {
                $count++;
                if ($count > self::RETRY_TIMES) {
                    throw new BeeperException($e->getMessage());
                    break;
                }
            }
        }

        $customerInfo = array_column(array_get($customer, 'info', []), null, 'cuid');
        foreach ($data as $k => $v) {
            $data[$k]['customerInfo'] = array_get($customerInfo, $v['customer_id'], []);
        }

        return $data;
    }

    /**
     * Get adc's information by adc id
     *
     * @param array $data
     * @return array
     * @throws BeeperException
     */
    private function getAdc($data)
    {
        $adcIds = array_column($data, 'adc_id');
        $params = [
            'where' => [
                'adcid' => [
                    '$in' => array_flip(array_flip($adcIds))
                ]
            ]
        ];

        $adc = [];
        $count = 0;
        while (true) {
            try {
                $adc = json_decode(YnRequest::get(config('api.base_api.adc.get_adcs_by_adc_id'), $params, []), true);
                if (array_get($adc, 'code') != 0) {
                    throw new BeeperException('getAdc : ' . array_get($adc, 'msg'));
                }
                break;
            } catch (\Exception $e) {
                $count++;
                if ($count > self::RETRY_TIMES) {
                    throw new BeeperException($e->getMessage());
                    break;
                }
            }
        }

        $adcInfo = array_column(array_get($adc, 'info', []), 'name_with_tags_display', 'adcid');
        foreach ($data as $k => $v) {
            $data[$k]['adcInfo'] = array_get($adcInfo, $v['adc_id'], '');
        }

        return $data;
    }

    /**
     * Get the information about bid
     *
     * @param int $transTaskId
     * @param int $transDriverBidId
     * @return array|mixed
     * @throws BeeperException
     */
    private function getBidInfo($transTaskId, $transDriverBidId)
    {
        $result = [
            'count' => 0,
            'createdAt' => '',
            'sourceDisplay' => ''
        ];

        $params = [
            'page' => 1,
            'perpage' => 200,
            'trans_task_id' => $transTaskId
        ];

        $count = 0;
        while (true) {
            try {
                //获取司机竞价列表信息
                $response = json_decode(YnRequest::get(config('api.tf_api.bid.list'), $params, []), true);
                if (array_get($response, 'code') == 0) {
                    $result['count'] = array_get($response, 'info.count');
                    $driverBidList = array_column(array_get($response, 'info.list'), null, 'id');
                    $result['createdAt'] = array_get($driverBidList, $transDriverBidId . '.created_at', '');
                } else {
                    throw new BeeperException('getBidInfo-bid list : ' . array_get($response, 'msg'));
                }

                //获取司机竞标日志信息
                if (array_get($result, 'createdAt')) {
                    $params = [
                        'bid_id' => $transDriverBidId,
                        'page' => 1,
                        'perpage' => 20
                    ];

                    $response = json_decode(YnRequest::get(config('api.tf_api.bid.logs'), $params, []), true);
                    if (array_get($response, 'code') == 0) {
                        $sourceDisplay = array_column(array_get($response, 'info.list'), 'source_display', 'action');
                        $result['sourceDisplay'] = array_get($sourceDisplay, '选中司机', '');
                    } else {
                        throw new BeeperException('getBidInfo-bid log : ' . array_get($response, 'msg'));
                    }
                }
                break;
            } catch (\Exception $e) {
                $count++;
                if ($count > self::RETRY_TIMES) {
                    log::error($e->getMessage());
                    break;
                }
            }
        }

        return $result;
    }

    /**
     * get operating terminal about transport task
     *
     * @param int $transTaskId
     * @return mixed|string
     * @throws BeeperException
     */
    private function getOperatingTerminal($transTaskId)
    {
        $operatingTerminal = '';

        $count = 0;
        while (true) {
            try {
                //获取线路任务操作log
                $response = json_decode(YnRequest::get(config('api.mt_api.task_log.list'), [
                    'page' => 1,
                    'perpage' => 20,
                    'trans_task_id' => $transTaskId
                ], []), true);

                if (array_get($response, 'code') == 0) {
                    $taskLog = array_column(array_get($response, 'info.list'), 'operating_terminal', 'action');
                    $operatingTerminal = array_get($taskLog, 200, '');
                } else {
                    throw new BeeperException('getOperatingTerminal : ' . array_get($response, 'msg'));
                }
                break;
            } catch (\Exception $e) {
                $count++;
                if ($count > self::RETRY_TIMES) {
                    log::error($e->getMessage());
                    break;
                }
            }
        }

        return $operatingTerminal;
    }

    /**
     * Get mileage
     *
     * @param int $eventId
     * @param int $transTaskId
     * @param int $customerId
     * @param int $driverId
     * @return float|int
     * @throws BeeperException
     */
    private function getMileage($eventId, $transTaskId, $customerId, $driverId)
    {
        $mileage = 0;

        $count = 0;
        while (true) {
            try {
                $response = json_decode(YnRequest::get(config('api.tf_api.event.calendar'), [
                    'page' => 1,
                    'perpage' => 20,
                    'only_for_driver' => 1,
                    'status' => 900,
                    'date' => Carbon::parse($this->dateStart)->format('Y-m-d'),
                    'trans_task_id' => $transTaskId,
                    'driver_id' => $driverId,
                    'customer_id' => $customerId,
                ], []), true);

                $itid = 0;
                if (array_get($response, 'code') == 0) {
                    $calendars = array_column(array_get($response, 'info.list'), 'tms_id', 'event_id');
                    $itid = array_get($calendars, $eventId, 0);
                } else {
                    throw new BeeperException('getMileage-calendar : ' . array_get($response, 'msg'));
                }

                if ($itid) {
                    $response = json_decode(YnRequest::post(config('api.location_api.location.mileage'), [
                        'data' => json_encode(['itid' => $itid])
                    ], []), true);

                    $mileage = round(array_get($response, 'info.0.mileage', 0) / 1000, 2);
                }
                break;
            } catch (\Exception $e) {
                $count++;
                if ($count > self::RETRY_TIMES) {
                    log::error($e->getMessage());
                    break;
                }
            }
        }

        return $mileage;
    }
}
