<?php

namespace App\Console\Commands\CustomerClue;

use Illuminate\Console\Command;
use App\Modules\CustomerClue\Repositories\ClueAdcRepository;
use App\Modules\CustomerClue\Models\ClueModel;
use App\Modules\CustomerClue\Models\AdminUserModel;
use App\Exceptions\BeeperException;

class UpdateClueBD extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'clue:update_clue_adc_id_bd_id {--filepath=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '更新线索表中管理区与bd信息';

    private $clueAdcRepository;
    private $clueModel;
    private $adminUserModel;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(ClueAdcRepository $clueAdcRepository, ClueModel $clueModel, AdminUserModel $adminUserModel)
    {
        $this->clueAdcRepository = $clueAdcRepository;
        $this->clueModel = $clueModel;
        $this->adminUserModel = $adminUserModel;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $dataGenerator = $this->dataGenerator();
        $filePath = $this->option('filepath');

        foreach ($dataGenerator as $list) {
            for ($i=0; $i<count($list); $i++) {
                try {
                    if ($list[$i]['adc_id'] == 0) {
                        if ($list[$i]['informant_id'] == 0) {
                            $userCond = [];
                            $userCond['admin_user_id'] = $list[$i]['creator_id'];
                            $uInfo = $this->adminUserModel->getAdminUserById($userCond);
                            $uInfo['_id'] = array_get($uInfo, 'admin_user_id', '');
                            $bdInfo = $this->clueAdcRepository->getBdInfo($uInfo, $list[$i]['city_id']);
                            $updateCond = [];
                            $updateCond['id'] = $list[$i]['id'];
                            $updateCond['business_development_id'] = $bdInfo['business_development_id'];
                            $updateCond['adc_id'] = $bdInfo['adc_id'];
                            if ($updateCond['business_development_id'] == 0) {
                                file_put_contents($filePath, "clue id" . $list[$i]['id'] . "don't have bd" . "\r\n", FILE_APPEND);
                            }
                            $this->clueModel->update($updateCond);
                        } else {
                            $baseCityId = $this->clueAdcRepository->getBaseCity($list[$i]['city_id']);
                            $adcid = $this->clueAdcRepository->getCityAdc($baseCityId);
                            $randomAdcBD = $this->clueAdcRepository->getAdcBD($adcid);
                            $updateCond = [];
                            $updateCond['id'] = $list[$i]['id'];
                            $updateCond['adc_id'] = $adcid;
                            $updateCond['business_development_id'] = array_get($randomAdcBD, 'admin_user_id', 0);
                            if ($updateCond['business_development_id'] == 0) {
                                file_put_contents($filePath, "clue id" . $list[$i]['id'] . "don't have bd" . "\r\n", FILE_APPEND);
                            }
                            $this->clueModel->update($updateCond);
                        }
                    }
                } catch (BeeperException $exceptione) {
                    file_put_contents($filePath, "error: update clue id".$list[$i]['id']." have error:".$exceptione->getMessage()."\r\n", FILE_APPEND);
                }
            }
        }
    }
    /**
     * Data source generator.
     *
     * @return mixed
     */
    public function dataGenerator()
    {
        $query = ['page' => 1];
        $count = 0;
        while (true) {
            try {
                $response = $this->clueModel->getList($query);
                $list = array_get($response, 'list', []);
                if (empty($list)) {
                    break;
                }
                $count = $count + count($list);
                $total = array_get($response, 'count', 0);
                $query['page'] += 1;

                yield $list;

                if ($count >= $total) {
                    break;
                }
            } catch (\Exception $e) {
                throw new BeeperException($e->getMessage(), config('custom_code.service_error.code'), null, 'error');
            }
        }
    }
}
