<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * 获取新A端导航栏信息
 *
 * @author zhangjunwei
 */
class HeaderFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'headerinfo';
    }
}
