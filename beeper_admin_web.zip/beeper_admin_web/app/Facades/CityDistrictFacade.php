<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

/**
 * 城市区县选择器组件
 *
 * @author changhu
 */
class CityDistrictFacade extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'citydistrictblade';
    }
}
