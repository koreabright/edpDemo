#!/bin/bash
# eslint检查，只检查修改的文件
#
# If you absolutely must commit without testing,
# use: git commit --no-verify

# This will check only staged files to be commited.
list=`git diff --relative --name-only HEAD | grep -e '.js$'`;

if [[ "$list" = "" ]]; then
  exit 0
fi

PASS=true;

for FILE in $list
do
  ./app/Frontend/node_modules/.bin/eslint --fix --config=./app/Frontend/.eslintrc.json \
  --ignore-path=./app/Frontend/.eslintignore --ext=.js \
  --color "$FILE";

  if [[ "$?" != 0 ]]; then
    echo "ESLint Failed: $FILE"
    PASS=false
  fi
done

echo "Javascript validation completed!"

if ! $PASS; then
  echo -e "commit failed: Your commit contains files that should pass ESLint but do not. Please fix the ESLint errors and try again."
  exit 1
else
  echo "well done!"
fi
exit $?

# if [ -n "$list" ]; then
#    ./app/Frontend/node_modules/.bin/eslint --fix && \
#	./app/Frontend/node_modules/.bin/eslint \
#	--config=./app/Frontend/.eslintrc.json \
#	--ignore-path=./app/Frontend/.eslintignore \
#	--no-ignore \
#	--ext=.js --color --cache \
#	--cache-location=./app/Frontend/.eslint-cache $list \
#	&& echo -e '\e[1;32m eslint well done ! \e[0m';
# fi

exit $?;

