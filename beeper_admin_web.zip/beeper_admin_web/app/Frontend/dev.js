/**
 * 启动本地服务的时候改写pre-commit;
 */
var fs = require('fs');
var fileReadStream = fs.createReadStream('./eslint.sh');
var fileWriteStream = fs.createWriteStream('../../.git/hooks/pre-commit');

fileReadStream.on('data', function (data) {
	fileWriteStream.write(data);
});

fileReadStream.on('end', function () {
	console.log('pre-commit has been created watch your code');
	fileWriteStream.end();
});
