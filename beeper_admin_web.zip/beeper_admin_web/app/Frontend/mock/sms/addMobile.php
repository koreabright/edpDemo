<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$info = array(
	'sms_oper' => array(
		0 => array(
			'value' => 'dahan',
			'desc' => '大汉三通'
		),
		1 => array(
			'value' => 'baiwu',
			'desc' => '百悟'
		),
		2 => array(
			'value' => 'alidayu',
			'desc' => '阿里大鱼'
		)
	),

	'inter_type' => array(
		0 => array(
			'value' => 'boss',
			'desc' => '平台拦截'
		),
		1 => array(
			'value' => 'operator',
			'desc' => '服务商拦截'
		)
	),

	'rem_txt' => array(
		0 => array(
			'value' => 'never',
			'desc' => '平台禁止'
		),
		1 => array(
			'value' => 'td',
			'desc' => 'TD'
		),
		2 => array(
			'value' => 'complaint',
			'desc' => '投诉'
		),
		3 => array(
			'value' => 'driver',
			'desc' => '司机设置不可用'
		)
	)
);
$info['user'] = $user;
$info['menu'] = $user_permissions;
$smarty->assign('info', $info);
$smarty->display('sms/addMobile.tpl');
