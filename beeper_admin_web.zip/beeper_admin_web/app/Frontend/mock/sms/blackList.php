<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$info = array(
	'sms_oper' => array(
		0 => array(
			'value' => 'dahan',
			'desc' => '大汉三通'
		),
		1 => array(
			'value' => 'baiwu',
			'desc' => '百悟'
		),
		2 => array(
			'value' => 'alidayu',
			'desc' => '阿里大鱼'
		)
	),

	'inter_type' => array(
		0 => array(
			'value' => 'boss',
			'desc' => '平台拦截'
		),
		1 => array(
			'value' => 'operator',
			'desc' => '服务商拦截'
		)
	),

	'rem_txt' => array(
		0 => array(
			'value' => 'never',
			'desc' => '平台禁止'
		),
		1 => array(
			'value' => 'td',
			'desc' => 'TD'
		),
		2 => array(
			'value' => 'complaint',
			'desc' => '投诉'
		),
		3 => array(
			'value' => 'driver',
			'desc' => '司机设置不可用'
		)
	),

	'table_list' => array(
		0 => array(
			'id' => '1', // 黑名单id
			'mobile' => '13197654436', // 电话号码
			'sms_operator' => '大汉三通', // 拦截服务商
			'intercept_type' => 'boss', // 拦截方式code
			'intercept_type_display' => '服务商拦截', // 拦截方式文本
			'rem' => '平台禁止', // 拦截说明
			'created_at' => '2016-11-21' // 创建时间
		),
		1 => array(
			'id' => '2',
			'mobile' => '13297654436',
			'sms_operator' => '阿里大鱼',
			'intercept_type' => 'operator',
			'intercept_type_display' => '平台拦截',
			'rem' => '平台禁止',
			'created_at' => '2016-11-21'
		)
	),
	'page_count' => 4,
	'current' => 4

);
$info['user'] = $user;
$info['menu'] = $user_permissions;
$smarty->assign('info', $info);
$smarty->assign('header', $info);
$smarty->display('sms/blackList.tpl');
