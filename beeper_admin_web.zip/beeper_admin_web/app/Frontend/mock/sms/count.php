<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$info = array(
	'sms_oper' => array(
		0 => array(
			'value' => 'dahan',
			'desc' => '大汉三通'
		),
		1 => array(
			'value' => 'baiwu',
			'desc' => '百悟'
		),
		2 => array(
			'value' => 'alidayu',
			'desc' => '阿里大鱼'
		)
	),

	'table_list' => array(
		0 => array(
			'scene' => '测试环境发布', // 发送场景
			'mobile' => '12345678909', // 手机号
			'text' => '【测试】cyr_customer1-bj_bj_warehouse1_1- 线路任务010239889 ,司机北京司机111088881110, 约定到仓时间为 2016-11-23 23:00 司机还没有签到', // 短信内容
			'result' => '成功', // 发送状态
			'sms_operator' => '大汉三通', // 服务商
			'created_at' => '2016-11-23 22:55:07', // 发送时间
			'error' => '' // 错误信息
		),
		1 => array(
			'scene' => '测试环境发布',
			'mobile' => '13598765209',
			'text' => '【测试】cyr-cyr_store- test_线路111 ,司机测试司机11111111111, 约定到仓时间为 2016-11-23 23:00 司机还没有签到',
			'result' => '失败',
			'sms_operator' => '阿里大鱼',
			'created_at' => '2016-11-23 22:55:07',
			'error' => '错误码:号码不在白名单里 错误信息:undefined'
		)
	),
	'page_count' => 4,
	'current' => 4,
	'total' => 80
);
$info['user'] = $user;
$info['menu'] = $user_permissions;
$smarty->assign('info', $info);
$smarty->assign('header', $info);
$smarty->display('sms/count.tpl');
