<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$info = array(
	'sms_oper' => array(
		0 => array(
			'value' => 'dahan',
			'desc' => '大汉三通'
		),
		1 => array(
			'value' => 'baiwu',
			'desc' => '百悟'
		),
		2 => array(
			'value' => 'alidayu',
			'desc' => '阿里大鱼'
		)
	),

	'inter_type' => array(
		0 => array(
			'value' => 'boss',
			'desc' => '平台拦截'
		),
		1 => array(
			'value' => 'operator',
			'desc' => '服务商拦截'
		)
	),

	'rem_txt' => array(
		0 => array(
			'value' => 'never',
			'desc' => '平台禁止'
		),
		1 => array(
			'value' => 'td',
			'desc' => 'TD'
		),
		2 => array(
			'value' => 'complaint',
			'desc' => '投诉'
		),
		3 => array(
			'value' => 'driver',
			'desc' => '司机设置不可用'
		)
	),

	'id' => '200', // 黑名单号码id
	'mobile' => '13197654436,18029762146', // 电话号码
	'sms_operator' => 'dahan', // 拦截服务商code
	'sms_operator_display' => '大汉三通', // 拦截服务商
	'intercept_type' => 'operator', // 拦截方式code
	'intercept_type_display' => '服务商拦截', // 拦截方式
	'rem' => 'never', // 拦截说明code
	'rem_display' => '平台禁止' // 拦截说明
);
$info['user'] = $user;
$info['menu'] = $user_permissions;
$smarty->assign('info', $info);
$smarty->assign('header', $info);
$smarty->display('sms/addMobile.tpl');
