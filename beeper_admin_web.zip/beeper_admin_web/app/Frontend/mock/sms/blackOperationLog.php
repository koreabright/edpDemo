<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$info = array(
    'table_list' => array(
        0 => array(
            'mobile' => '13197654436', // 电话号码
            'operation' => '编辑', // 操作
            'created_at' => '2016-11-21 10:23:01', // 时间
            'username' => '张三', // 操作人
            'info' => '其他信息' // 其他信息
        ),
        1 => array(
            'mobile' => '13197654436',
            'operation' => '删除',
            'created_at' => '2016-11-30 10:23:01',
            'username' => '李四',
            'info' => '其他信息'
        )
    ),
    'page_count' => 4,
    'current' => 4,
    'total' => 200
);
$info['user'] = $user;
$info['menu'] = $user_permissions;
$smarty->assign('info', $info);
$smarty->assign('header', $info);
$smarty->display('sms/blackOperationLog.tpl');
