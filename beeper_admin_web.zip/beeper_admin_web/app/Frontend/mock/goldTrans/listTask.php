<?php
require('../initer.php');

$info = [
];

$smarty->assign('info', $info);
$smarty->display('goldTrans/listTask.tpl');
?>