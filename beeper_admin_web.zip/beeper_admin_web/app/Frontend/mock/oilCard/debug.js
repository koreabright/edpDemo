module.exports = {
	"/new/api/oil_card_record/get_list": "/mock/oilCard/data/oilCardRecord.json"
};
