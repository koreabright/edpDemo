<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = json_decode(file_get_contents('./data/billRevision.json'), true);


$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $fis_data);

$smarty->display('bill/billRevision.tpl');
