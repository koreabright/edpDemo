<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$info = json_decode(file_get_contents('./data/billDetail.json'), true);


$info["user"] = $user;
$info["menu"] = $user_permissions;

$smarty -> assign('info', $info);
$smarty -> assign('header', $info);

$smarty->display('bill/billDetail.tpl');
