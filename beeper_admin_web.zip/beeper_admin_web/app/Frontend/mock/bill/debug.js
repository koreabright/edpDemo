module.exports = {
	// FLBP
	'/new/api/finance/customer_draw_money/delete': '/mock/FLBP/data/succ.json',
	'/new/api/finance/customer_draw_money/get_list': '/mock/FLBP/data/list_data.json',
	'/new/api/finance/customer_draw_money/do_chargein': '/mock/FLBP/data/succ.json',
	'/new/api/finance/customer_draw_money/get_customer_info': '/mock/FLBP/data/autoComplete.json',


	'/new/api/finance/customer_bill/business_log': '/mock/bill/data/detailBusinessLog.json',
	'/new/api/finance/customer_bill/do_adjust_audit': '/mock/bill/data/succ.json',
	'/new/api/finance/yqzl_virtual_account/list': '/mock/bill/data/bank.json',
	'/new/api/finance/yqzl_virtual_account/get_customer_info': '/mock/bill/data/tax.json',
	'/new/api/finance/customer_bill/do_apply_adjust': '/mock/bill/data/succ.json',

	// 一桶油充值
	"/new/api/finance/driver_consume/yitongyou/list": "/mock/finance/data/barrelOilRechargeList.json",

	// 客户开票资质列表
	"/new/api/finance/customer_receipt_credential/list": "/mock/finance/data/receiptCredentialList.json",
	// 修改开票资质数据
	"/new/api/finance/customer_receipt_credential/update": "/mock/finance/data/editReceiptItem.json",
	// 新增开票资质
	"/new/finance/customer_receipt_credential/create": "/mock/finance/data/editReceiptItem.json",
	
	// 客户账单
	"/new/api/finance/customer_draw_money/get_debt_bills": "/mock/FLBP/data/get_debt_bill.json"
};
