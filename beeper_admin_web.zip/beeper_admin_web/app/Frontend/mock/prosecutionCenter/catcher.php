<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = json_decode(file_get_contents('./catcher.json'), true);


$header["user"] = $user;
$header["menu"] = $user_permissions;

$fis_data["user"] = $user;
$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $header);

$smarty->display('prosecutionCenter/catcher.tpl');
