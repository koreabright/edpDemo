<?php
require('../initer.php');


$smarty->display('captain/addCaptain.tpl');
?>