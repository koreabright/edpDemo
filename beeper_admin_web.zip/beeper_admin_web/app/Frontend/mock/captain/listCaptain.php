<?php
require('../initer.php');

$info = [
];

$smarty->assign('info', $info);
$smarty->display('captain/listCaptain.tpl');
?>