<?php
require('../initer.php');

$info = [
];

$smarty->assign('info', $info);
$smarty->display('driver/item_distribute.tpl');
?>
