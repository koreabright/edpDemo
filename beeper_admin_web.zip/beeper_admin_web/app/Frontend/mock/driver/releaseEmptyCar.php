<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/releaseEmptyCar.json'), true);

$smarty->assign('info', $info);
$smarty->display('driver/releaseEmptyCar.tpl');
