<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/trackLog.json'), true);

$smarty->assign('info', $info);
$smarty->display('driver/trackLog.tpl');
?>