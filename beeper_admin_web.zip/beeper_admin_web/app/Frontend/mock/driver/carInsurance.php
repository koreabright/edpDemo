<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/carInsurance.json'), true);

$smarty->assign('info', $info);
$smarty->display('driver/carInsurance.tpl');