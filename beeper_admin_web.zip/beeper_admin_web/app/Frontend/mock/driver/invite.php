<?php
require('../initer.php');

$info = [
    'auth' => [
        'do_edit_driver_invite_paid' => true,
        'do_export_driver_invite_list' => true
    ]
];

$smarty->assign('info', $info);
$smarty->display('driver/invite.tpl');
