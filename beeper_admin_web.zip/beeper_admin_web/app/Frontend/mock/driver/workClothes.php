<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/workClothes.json'), true);

$smarty->assign('info', $info);
$smarty->display('driver/workClothes.tpl');
