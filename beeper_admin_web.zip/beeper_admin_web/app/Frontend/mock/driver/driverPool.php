<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/driverPool.json'), true);

$smarty->assign('info', $info);
$smarty->display('driver/driverPool.tpl');
