<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/receiptList.json'), true);

$smarty->assign('info', $info);
$smarty->display('receipt/receiptList.tpl');
?>