<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/receiptTimeConfig.json'), true);

$smarty->assign('info', $info);
$smarty->display('receipt/receiptTimeConfig.tpl');
?>