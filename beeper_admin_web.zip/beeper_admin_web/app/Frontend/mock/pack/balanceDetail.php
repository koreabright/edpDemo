<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$info = array();
$info['user'] = $user;
$info['menu'] = $user_permissions;
$smarty->assign('info', $info);
$smarty->assign('header', $info);
$smarty->display('pack/balanceDetail.tpl');
