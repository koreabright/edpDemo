module.exports = {
	'/new/api/pack/balance_income/get_charge': '/mock/pack/balanceIncomeCharge.json',
	'/new/api/pack/balance_income/save': '/mock/pack/success.json',
	'/new/api/pack/balance_income/detail': '/mock/pack/balanceIncomeDetail.json',
	'/new/api/pack/balance_income/update': '/mock/pack/success.json',
	'/new/api/pack/order_center/report_update': '/mock/orderCenter/data/update.json',
	'/new/api/pack/order_center/customers': '/mock/pack/orderCenterCustomerList.json',

	"/new/api/pack/charge/save": "/mock/customer/data/common.json",									// 保存
	"/new/api/pack/charge/definition/delete": "/mock/customer/data/common.json", 		// 删除明细设置
	"/new/api/pack/charge/confirm": "/mock/customer/data/common.json",		// 确认价格
	"/new/api/pack/charge/change_settlement": "/mock/customer/data/common.json",		// 启动/停止订单中心结算方式
	// 财务 计费明细
	"/new/api/pack/charge/detail": "/mock/customer/data/packageInfo.json"				// 获取所有数据
};
