<?php

require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    "total_page" => 10,
    "page" => 1,
    "factor_id" => "113",
    "total" => "10",
    "table_list" => array(
        0 => array(
            "id" => "0111",
            "customer_id" => '1001',
            "company_name" => "保理商名称",
            "created_at" => "2016-11-11 09:20:12"
        ),
        1 => array(
            "id" => "0111",
            "customer_id" => '1001',
            "company_name" => "保理商名称",
            "created_at" => "2016-11-11 09:20:12"
        ),
        2 => array(
            "id" => "0111",
            "customer_id" => '1001',
            "company_name" => "保理商名称",
            "created_at" => "2016-11-11 09:20:12"
        )
    )
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('factor/factorCustomer.tpl');