<?php

require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    date => '2016-08-08',
    week => '1',
    "table_list" => array(
        0 => array(
            "id" => "0111",
            "full_name" => "保理商名称",
            "contact_name" => "路易斯",
            "contact_phone" => "1006678900",
            "customer_count" => 100,
            "user_count" => 10,
            "created_at" => "2016-11-11 09:20:12"
        ),
        1 => array(
            "id" => "0111",
            "full_name" => "保理商名称",
            "contact_name" => "路易斯",
            "contact_phone" => "1006678900",
            "customer_count" => 100,
            "user_count" => 10,
            "created_at" => "2016-11-11 09:20:12"
        ),
        2 => array(
            "id" => "0111",
            "full_name" => "保理商名称",
            "contact_name" => "路易斯",
            "contact_phone" => "1006678900",
            "customer_count" => 100,
            "user_count" => 10,
            "created_at" => "2016-11-11 09:20:12"
        )
    )
);

$fis_data["user"] = $user;
$header = array();
$header['menu'] = $user_permissions;
$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $header);
$smarty->display('factor/factorList.tpl');