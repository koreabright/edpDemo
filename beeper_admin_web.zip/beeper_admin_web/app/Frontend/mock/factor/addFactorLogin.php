<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    date => '2016-08-08',
    week => '1'
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('factor/addFactorLogin.tpl');