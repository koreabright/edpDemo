module.exports = {
	'/new/factoring/api/customer/check': '/mock/factor/addCustomerCheck.json',
	'/new/factoring/api/customer/add': '/mock/factor/addCustomerAdd.json',
	'/new/factoring/api/user/add': '/mock/factor/addCustomerAdd.json',
	'/new/factoring/api/factor/add': '/mock/factor/addCustomerAdd.json',
	'/new/api/factor/user/disable': '/mock/factor/addCustomerAdd.json',
	'/new/api/factor/user/reset_password': '/mock/factor/addCustomerAdd.json'
};