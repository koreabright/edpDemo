<?php
/**
 * Created by PhpStorm.
 * User: linjing
 * Date: 2016/11/14
 * Time: 17:57
 */

require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$interview_peoples = json_decode(file_get_contents('./interview_peoples.json'), true);
$fis_data = array(
    date => '2016-08-08',
    week => '1',
    addable => 1,
    interview_status_config => array(
        0 => array(
            code =>'100',
            desc =>'面试中'
        ),
        1 => array(
            code =>'200',
            desc =>'以归档'
        )
    ),
    city_config => array(
        0 => array(
            id =>'01',
            name =>'北京市'
        ),
        1 => array(
            id =>'02',
            name =>'上海市'
        ),
        3 => array(
            id =>'03',
            name =>'成都市'
        )
    )
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$fis_data["interview_map"] = $interview_peoples;
$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $fis_data);

$smarty->display('operate/interviewList.tpl');