<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$interview_peoples = json_decode(file_get_contents('./interview_peoples.json'), true);
//新建面试的列表的状态配置
$fcc_status_config = json_decode(file_get_contents('./fcc_status_config.json'), true);
$fis_data = array(
    editable => 1,
    interview_id => 0,
    job_requirement => '我是说明',
    "customer_id"=> 141,
    "warehouse_id"=> 165,
    "sales_id"=> 1000180,
    "quality_mgr_id"=> 1000141,
    "creator_id"=> 1000232,
    "status"=> 100,
    "adc_id"=> 1,
    "city_id"=> 1,
    "created_at"=> "2016-12-14 10:11:23",
    "updated_at"=> "2016-12-14 10:11:23",
    "customer_name"=> "shiyang_3",
    "warehouse_name"=> "A",
    "adc_name"=> "北京管理区",
    "city_name"=> "北京市",
    "sales_name"=> "刘诗杨-客服经理-北京2",
    "quality_mgr_name"=> "dy运作经理",

);





$header["user"] = $user;
$header["menu"] = $user_permissions;

$fis_data["user"] = $user;
$fis_data["interview_map"] = $interview_peoples;
$fis_data["enable_status"] = $fcc_status_config;
$fis_data["fcc_status_config"] = $fcc_status_config;
$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $header);

$smarty->display('operate/addInterview.tpl');