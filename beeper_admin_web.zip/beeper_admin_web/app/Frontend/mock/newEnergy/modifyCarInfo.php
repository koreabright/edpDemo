<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/carDetail.json'), true);
$info["cities"] = array(
	array(
		"id" => 1,
		"name" => "北京市",
		"city_areas" =>array(
			array(
				"id" => 35,
				"name" => "朝阳区",
			),
			array(
				"id" => 36,
				"name" => "海淀区",
			),
			array(
				"id" => 37,
				"name" => "东城区",
			)
		)
	),
	array(
		"id" => 2,
		"name" => "上海市",
		"city_areas" =>array(
			array(
				"id" => 35,
				"name" => "朝阳区",
			),
			array(
				"id" => 36,
				"name" => "海淀区",
			),
			array(
				"id" => 37,
				"name" => "东城区",
			)
		)
	)
);

$smarty->assign('info', $info);
$smarty->display('newEnergy/modifyCarInfo.tpl');
