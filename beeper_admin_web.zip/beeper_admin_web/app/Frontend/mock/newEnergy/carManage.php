<?php
require('../initer.php');

$info = array(
    "car_status" => array(
		array(
			"code" => 100,
			"desc" => "闲置中"
		),
		array(
			"code" => 200,
			"desc" => "已绑定司机"
		),
		array(
			"code" => 300,
			"desc" => "已停用"
		)
	),
	"driver_licence_level" => array(
		array(
			"code" => 100,
			"desc" => "A1"
		),
		array(
			"code" => 200,
			"desc" => "A2"
		)
	),
	"is_operable" => 1,
	"yn_cities" => array(
		array(
			"id" => 1,
			"name" => "北京市",
			"city_areas" =>array(
				array(
					"id" => 35,
					"name" => "朝阳区",
				),
				array(
					"id" => 36,
					"name" => "海淀区",
				),
				array(
					"id" => 37,
					"name" => "东城区",
				)
			)
		),
		array(
			"id" => 2,
			"name" => "上海市",
			"city_areas" =>array(
				array(
					"id" => 35,
					"name" => "朝阳区",
				),
				array(
					"id" => 36,
					"name" => "海淀区",
				),
				array(
					"id" => 37,
					"name" => "东城区",
				)
			)
		)
	)
);

$smarty->assign('info', $info);
$smarty->display('newEnergy/carManage.tpl');
