<?php
require('../initer.php');

$info = array(
    "citizen_group_approve" => array(
		array(
			"code" => -1,
			"desc" => "未提交"
		),
		array(
			"code" => 100,
			"desc" => "待审核"
		),
		array(
			"code" => 200,
			"desc" => "审核通过"
		),
		array(
			"code" => 300,
			"desc" => "审核拒绝"
		),
		array(
			"code" => 400,
			"desc" => "审核已过期"
		)
	),
	"driver_licence_level" => array(
		array(
			"code" => 100,
			"desc" => "A1"
		),
		array(
			"code" => 200,
			"desc" => "A2"
		)
	),
	"yn_cities" => array(
		array(
			"id" => 1,
			"name" => "北京市",
			"city_areas" =>array(
				array(
					"id" => 35,
					"name" => "朝阳区",
				),
				array(
					"id" => 36,
					"name" => "海淀区",
				),
				array(
					"id" => 37,
					"name" => "东城区",
				)
			)
		),
		array(
			"id" => 2,
			"name" => "上海市",
			"city_areas" =>array(
				array(
					"id" => 35,
					"name" => "朝阳区",
				),
				array(
					"id" => 36,
					"name" => "海淀区",
				),
				array(
					"id" => 37,
					"name" => "东城区",
				)
			)
		)
	)
);

$smarty->assign('info', $info);
$smarty->display('newEnergy/driverList.tpl');
