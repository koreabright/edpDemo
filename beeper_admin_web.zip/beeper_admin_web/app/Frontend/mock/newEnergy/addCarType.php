<?php
require('../initer.php');

$info = array(
	"driver_licence_level" => array(
		array(
			"code" => 100,
			"desc" => "A1"
		),
		array(
			"code" => 200,
			"desc" => "A2"
		)
	)
);

$smarty->assign('info', $info);
$smarty->display('newEnergy/addCarType.tpl');
