<?php
require('../initer.php');

$info = array(
	"driver_licence_level" => array(
		array(
			"code" => 100,
			"desc" => "A1"
		),
		array(
			"code" => 200,
			"desc" => "A2"
		),
		array(
			"code" => 300,
			"desc" => "A3"
		),
		array(
			"code" => 400,
			"desc" => "A4"
		)
	),
	"detail" => array(
		"id" => 1,
		"ctid" => 1,
		"ct_name" => "小面",
		"car_brand" => "广汽",
		"car_model" => "G111",
		"mileage" => 200,
		"battery_capacity" => 16,
		"charge_voltage" => 220,
		"back_up_voltage" => 220,
		"created_at" => "0000-00-00 00:00:00",
		"updated_at" => "0000-00-00 00:00:00",
		"driver_licence_level" => "1,2,3",
		"driver_licence_level_arr" => array(200,100)
	)

);

$smarty->assign('info', $info);
$smarty->display('newEnergy/editCarType.tpl');
