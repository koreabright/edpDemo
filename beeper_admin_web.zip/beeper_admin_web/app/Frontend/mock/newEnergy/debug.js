module.exports = {
	"/new/api/energy_vehicle/get_car_info": "/mock/newEnergy/data/carManage.json",
	"/new/api/energy_vehicle/get_brand_model": "/mock/newEnergy/data/brandModel.json",
	"/new/api/energy_vehicle/get_new_car_type": "/mock/newEnergy/data/newCarTypeInfo.json",
	"/new/api/energy_vehicle/show_op_log": "/mock/newEnergy/data/carOperationLog.json",
	"/new/api/energy_vehicle/get_energy_driver": "/mock/newEnergy/data/driverList.json",
	"/new/api/energy_vehicle/get_cities": "/mock/newEnergy/data/city.json",
	"/new/api/energy_car_type/get_car_type_list": "/mock/newEnergy/data/carTypeManage.json",
	"/new/api/energy_car_type/show_op_log": "/mock/newEnergy/data/carTypeOperationLog.json"
};
