<?php
require('../initer.php');

$info["yn_cities"] = json_decode(file_get_contents('./data/city.json'), true);

$smarty->assign('info', $info);
$smarty->display('newEnergy/addCar.tpl');
