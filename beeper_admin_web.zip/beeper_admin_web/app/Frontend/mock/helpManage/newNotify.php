<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$adc_config = json_decode(file_get_contents('./adcs.json'), true);


$fis_data = array(
    id=>1,//是否是详情
    is_all_adc=>1,//是否是全部管理区
    type_config=>array(   //通知形式下拉框
        0=>array(code=>121, desc=>"公告"),
        1=>array(code=>212, desc=>"带浮层弹窗"),
    ),
    project_type_config=>array(   //项目类型
        0=>array(code=>111, desc=>"封装"),
        1=>array(code=>222, desc=>"自助"),
    ),
    customer_type_config=>array(   //客户类型
        0=>array(code=>100, desc=>"信用客户"),
        1=>array(code=>200, desc=>"预充值客户"),
    ),
    adcids=>array(
        0=>1,
        1=>19,
    ),
    customer_type=>'',
    customer_project_type=>'',
    push_type=>212,
    title=>'this is title.',
    content=>'content',
    reason=>'this is reason',
);





$header["user"] = $user;
$header["menu"] = $user_permissions;

$fis_data["user"] = $user;
$fis_data["adc_config"] = $adc_config;
$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $header);

$smarty->display('helpManage/newNotify.tpl');