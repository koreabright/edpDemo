<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);


$fis_data = array(
    addable=>1,
    target_config=>array( //通知对象下拉框
            0=>array(code=>1, desc=>"A"),
            1=>array(code=>2, desc=>"B"),
        ),
    type_config=>array(   //通知形式下拉框
            0=>array(code=>1, desc=>"公告"),
            1=>array(code=>2, desc=>"带浮层弹窗"),
        )
);





$header["user"] = $user;
$header["menu"] = $user_permissions;
$header["unReadNewsCount"] = 0;

$fis_data["user"] = $user;
$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $header);

$smarty->display('helpManage/msgNotify.tpl');