<?php
require('../initer.php');

$info['task_info'] = json_decode(file_get_contents('./taskDetail.json'), true);

$smarty->assign('info', $info);
$smarty->display('task/dispatchDriver.tpl');
