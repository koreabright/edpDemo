<?php
require('../initer.php');

$info = array(
    "task_type_arr" => array(
        100 => "临时司机",
        200 => "主司机",
        300 => "签约司机",
    ),
    "task_substatus_arr" => array(
        1000 => "已发布",
        2000 => "运行中",
        2200 => "申请离职中",
        4000 => "任务完成",
        4210 => "司机已离职",
        4220 => "无责任解约",
        4230 => "司机违约",
        4240 => "客户违约",
        4250 => "开除",
        4260 => "云鸟开除",
        4270 => "财务停运",
        5000 => "客户废弃"
    ),
    "dispatch_bid_status_arr" => array(
        1200 => "司机抢单中",
        2200 => "选到可用司机",
        3210 => "任务作废",
        4210 => "无可派司机",
        4220 => "无司机抢单"
    ),
    "yn_car_types" => array(
		array(
			"ctid" => 1,
			"name" => "小面",
			"rank" => 0,
			"group" => "1",
			"is_lengmen" => 0,
			"alias" => "XIAOMIAN"
		),
		array(
			"ctid" => 2,
			"name" => "平顶金杯",
			"rank" => 2,
			"group" => "1",
			"is_lengmen" => 0,
			"alias" => "JINBEI"
		),
		array(
			"ctid" => 3,
			"name" => "高顶金杯",
			"rank" => 4,
			"group" => "1",
			"alias" => "JINBEI_GAO_DING"
		),
		array(
			"ctid" => 4,
			"name" => "高顶金杯",
			"rank" => 4,
			"group" => "1",
			"alias" => "JINBEI_GAO_DING"
		),
		array(
			"ctid" => 4,
			"name" => "高顶金杯",
			"rank" => 4,
			"group" => "1",
			"alias" => "JINBEI_GAO_DING"
		),
		array(
			"ctid" => 4,
			"name" => "高顶金杯",
			"rank" => 4,
			"group" => "1",
			"alias" => "JINBEI_GAO_DING"
		)
	),
	"urge_original_task_scene" => array(
		100 => "普通场景",
		200 => "救援场景",
		300 => "订单中心",
		400 => "促标抢单"
	)
);

$smarty->assign('info', $info);
$smarty->display('task/dispatchTaskList.tpl');
