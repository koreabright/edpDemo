<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/dispatchTaskList.json'), true);;

$smarty->assign('info', $info);
$smarty->display('task/publishUrgeDispatchTask.tpl');
