<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    "task_type_arr" => array(
        100 => "临时司机",
        200 => "主司机",
        300 => "签约司机",
    ),
    "task_match_type_arr" => array(
        100 => "竞价",
        200 => "抢单"
    ),
    "task_scene_arr" => array(
        100 => "普通场景",
        200 => "救援场景",
        300 => "订单中心"
    ),
    "task_substatus_arr" => array(
        1000 => "已发布",
        2000 => "运行中",
        2200 => "申请离职中",
        4000 => "任务完成",
        4210 => "司机已离职",
        4220 => "无责任解约",
        4230 => "司机违约",
        4240 => "客户违约",
        4250 => "开除",
        4260 => "云鸟开除",
        4270 => "财务停运",
        5000 => "客户废弃"
    ),
      "process_bid_status_arr" => array(
        2000 => "司机报价中",
        3000 => "选择司机中",
        4100 => "无司机报价",
        4200 => "任务作废",
        4310 => "无可选司机",
        4320 => "客户不选司机",
        4330 => "过期未选司机",
        4340 => "所选司机不可用且未改选",
        6000 => "选到可用司机"
    ),
      "dispatch_bid_status_arr" => array(
        1200 => "司机抢单中",
        2200 => "选到可用司机",
        3210 => "任务作废",
        4210 => "无可派司机",
        4220 => "无司机抢单"
    )
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('task/list.tpl');
