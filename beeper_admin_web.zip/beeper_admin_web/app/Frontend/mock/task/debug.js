module.exports = {
	"/new/api/match/urge/get_dispatch_task_list": "/mock/task/data/dispatchTaskList.json",
	"/new/api/match/urge/get_original_task_info": "/mock/task/data/publishUrgeDispatchTask.json",
	"/api/match/dispatch/validate_dispatch_driver": "/mock/task/data/dispatchDriver.json"
};
