<?php
require('../initer.php');

$info = [
];

$smarty->assign('info', $info);
$smarty->display('goldDriver/driverList.tpl');
?>