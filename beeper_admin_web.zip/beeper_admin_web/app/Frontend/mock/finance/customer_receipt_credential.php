<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);

$fis_data = array(
    'config' => array(
         'tax_rate' => array(
              0 => array(
                   'code' => '0.03',
                   'desc' => '3%'
              ),
              1 => array(
                   'code' => '0.06',
                   'desc' => '6%'
              ),
              2 => array(
                   'code' => '0.11',
                   'desc' => '11%'
              )
         ),
         'type' => array(
              0 => array(
                   'code' => '1',
                   'desc' => '增值税普通发票'
              ),
              1 => array(
                   'code' => '2',
                   'desc' => '增值税专用发票'
              )
         ),
         'status' => array(
              0 => array(
                    'code' => '0',
                    'desc' => '待审核'
              ),
              1 => array(
                     'code' => '1',
                     'desc' => '审核通过'
              ),
              2 => array(
                     'code' => '2',
                     'desc' => '审核不通过'
              )
         )
    )

);


$smarty -> assign('info', $fis_data);


$smarty->display('finance/customer_receipt_credential.tpl');
