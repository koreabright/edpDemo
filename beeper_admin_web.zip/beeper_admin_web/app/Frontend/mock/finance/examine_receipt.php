<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);

$fis_data = array(
    "credentail_info"=>array(
         id => 1,
    ),
    'config' => array(
        'type' => array(
            0 => array(
               'code' => '1',
               'name' => '增值税普通发票'
            ),
            1 => array(
               'code' => '2',
               'name' => '增值税专用发票'
            )
        )
    )
);

$smarty -> assign('info', $fis_data);
$smarty->display('finance/customer_receipt_credential..tpl');
