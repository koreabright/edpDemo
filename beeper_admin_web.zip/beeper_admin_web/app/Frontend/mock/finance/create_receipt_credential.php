<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$fis_data = json_decode(file_get_contents('./data/create_receipt.json'), true);

$smarty -> assign('info', $fis_data);
$smarty->display('finance/create_receipt_credential.tpl');
