<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/barrelOilRechargeList.json'), true);

$smarty->assign('info', $info);
$smarty->display('finance/barrelOilRechargeList.tpl');
