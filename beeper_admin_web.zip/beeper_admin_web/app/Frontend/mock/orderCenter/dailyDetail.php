<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);

$fis_data = json_decode(file_get_contents('./data/update.json'), true);

$header["user"] = $user;
$header["menu"] = $user_permissions;

$smarty -> assign('info', $fis_data['info']);
$smarty -> assign('header', $header);

$smarty->display('orderCenter/dailyDetail.tpl');
