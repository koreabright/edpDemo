<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);

$fis_data = array(
    "count" => 6,
    "page" => 1,
    "per_page" => 20,
    "total_page" => 1,
    "total" => 6,
    "balance_type" => array(
        0 => array(
            "code" => "100",
            "desc" => "收入"
        ),
        1 => array(
            "code" => "200",
            "desc" => "成本"
        )
    ),
    "balance_source" => array(
        0 => array(
            "code" => "100",
            "desc" => "顾问提交"
        ),
        1 => array(
            "code" => "200",
            "desc" => "系统生成"
        )
    )
);

$header["user"] = $user;
$header["menu"] = $user_permissions;

$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $header);

$smarty->display('orderCenter/dailyAdjust.tpl');
