<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);

$fis_data = array(
    "id" => 48,
    "customer_id" => 48,
    "customer_flag" => 400,
    "report_date_start" => "2017-07-01",
    "report_date_end" => "2017-07-31",
    "income" => 0,
    "income_money_display" => "0.00",
    "cost" => 0,
    "cost_money_display" => "0.00",
    "cost_total" => 0,
    "income_total" => 0,
    "bonus_total_display" => 0,
    "gross_profit" => 0,
    "gross_profit_rate" => "0.0000",
    "income_balance" => 31502100,
    "income_balance_display" => 315021.00,
    "cost_balance" => 31502100,
    "cost_balance_display" => 315021.00,
    "vas_bonus_rate" => "0.0000",
    "dd_bonus_rate" => "0.0000",
    "bid_bonus_rate" => "0.0000",
    "status" => 100,
    "committed_at" => 0,
    "saved_at" => 0,
    "created_at" => "2017-07-15 17:31:46",
    "updated_at" => "2017-07-17 11:07:39",
    "cost_total_display" => "0.00",
    "gross_profit_display" => "0.00",
    "gross_profit_rate_display" => "0%",
    "vas_bonus_rate_display" => "0%",
    "dd_bonus_rate_display" => "0%",
    "bid_bonus_rate_display" => "0%",
    "vas_bonus_cost_display" => 0,
    "dd_bonus_cost_display" => 0,
    "bid_bonus_cost_display" => 0,
    "customer_flag_display" => "订单封装",
    "charge_unit" => 400,
    "incomes" => array(
        0 => array(
            "detail_name" => "eeee",
            "money" => 0,
            "money_display" => "0.00"
        ),
        1 => array(
            "detail_name" => "eeee",
            "money" => 2,
            "money_display" => "2.00"
        ),
        2 => array(
            "detail_name" => "eeee",
            "money" => 111,
            "money_display" => "111.00"
        )
    ),
    "costs" => array(
        0 => array(
            "cost_name" => "eeee",
            "money" => 0,
            "money_display" => "0.00"
        ),
        1 => array(
            "cost_name" => "eeee",
            "money" => 1,
            "money_display" => "1.00"
        ),
        2 => array(
            "cost_name" => "eeee",
            "money" => 222,
            "money_display" => "222.00"
        ),
        3 => array(
            "cost_name" => "eeee",
            "money" => 233,
            "money_display" => "233.00"
        )
    ),
    "customer_info" => array(
        "cuid" => 4054,
        "name" => "封装用户空档期",
        "sales" => "bj_客服经理1",
        "adcid" => 1,
        "main_bid_mgr" => "王燕芳-岗经-北京2",
        "city" => "北京市",
        "mobile" => "11022222882",
        "com_name" => "封装用户空档期",
        "city_id" => 1,
        "main_bid_mgr_id" => 1000323,
        "sales_id" => 1000240,
        "company_id" => 2417,
        "tender_status" => 2,
        "finance_pay_type" => 100,
        "archived" => false,
        "ps" => 2,
        "pt" => 1,
        "now_invoice_tax_rate_value" => 0,
        "invoice_tax_rate_display" => "无",
        "vas_sop_spp_display" => "",
        "ps_display" => "已开跑",
        "pt_display" => "封装",
        "finance_pay_type_display" => "信用客户",
        "adc_info" => array(
            "adcid" => 1,
            "name" => "北京管理区"
        ),
        "bu_leader" => array(
            "name" => "hahah"
        )
    ),
    "count" => 6,
    "page" => 1,
    "per_page" => 20,
    "total_page" => 1,
    "total" => 6,
    "balance_type" => array(
        0 => array(
            "code" => "100",
            "desc" => "收入"
        ),
        1 => array(
            "code" => "200",
            "desc" => "成本"
        )
    ),
    "customer_flag_config" => array(
        0 => array(
            "code" => "400",
            "desc" => "订单封装"
        ),
        1 => array(
            "code" => "500",
            "desc" => "整车封装"
        )
    )
);

$header["user"] = $user;
$header["menu"] = $user_permissions;

$smarty -> assign('info', $fis_data);
$smarty -> assign('header', $header);

$smarty->display('orderCenter/monthlyDetail.tpl');
