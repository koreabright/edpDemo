<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);

$fis_data = array(
     'error' => 'sdgadg',
     'needCaptcha' => 1,
);


$smarty -> assign('info', $fis_data);
$smarty->display('login/login.tpl');