<?php
require('../initer.php');

$info = [
];

$smarty->assign('info', $info);
$smarty->display('goldCaptainFollow/captainFollow.tpl');
?>
