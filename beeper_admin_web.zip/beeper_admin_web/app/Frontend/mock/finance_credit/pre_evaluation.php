<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
		"last_pre" => array(
			'created_at'=> '2017-01-01 01:01:01',
            'preparing_created_at'=>'2017-02-02 01:01:01',#正在进行的预评分开始时间
           	'average'=> 40,
            'standard_deviation' => 6,
            'score_aptitude'=>15,#资质类平均分
            'score_operation'=>42#运营类平均分
		),
		"pagination" => array(
			"total" => 16,
			"total_pages" => 4
		),
		"list" => array(
			0 => array(
				'id'=>1,
	            'cuid'=>147,
	            'name'=>'云鸟',
	            'pt_display'=>'自助',
	            'score_aptitude'=>36,#资质类得分
	            'score_operation'=>42,#运营类得分
	            'score'=>78,#总分
	            'rank'=>128,#排名
	           	'star'=>1,
	            'created_at'=>'2017-01-01 01:01:01',
	            'updated_at'>'2017-01-01 02:02:02'
			),
			1 => array(
				'id'=>1,
	            'cuid'=>147,
	            'name'=>'云鸟',
	            'pt_display'=>'自助',
	            'score_aptitude'=>36,#资质类得分
	            'score_operation'=>42,#运营类得分
	            'score'=>78,#总分
	            'rank'=>128,#排名
	           	'star'=>1,
	            'created_at'=>'2017-01-01 01:01:01',
	            'updated_at'>'2017-01-01 02:02:02'
			),
			2 => array(
				'id'=>1,
	            'cuid'=>147,
	            'name'=>'云鸟',
	            'pt_display'=>'自助',
	            'score_aptitude'=>36,#资质类得分
	            'score_operation'=>42,#运营类得分
	            'score'=>78,#总分
	            'rank'=>128,#排名
	           	'star'=>1,
	            'created_at'=>'2017-01-01 01:01:01',
	            'updated_at'>'2017-01-01 02:02:02'
			)
		)
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('finance_credit/pre_evaluation.tpl');
