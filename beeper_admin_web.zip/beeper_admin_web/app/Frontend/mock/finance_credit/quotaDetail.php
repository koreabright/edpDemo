<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
	"list" => array(
		0 => array(
			"id"=> 1,
            "name"=> "企业性质",
            "base_type"=> 100,
            "secondary_type"=> 100,
            "rate_role"=> "FLBP",
            "desc"=> "企业性质",
            "compute_base"=> "100",
            "active_type"=> "100",
            "compute_time"=> "创建",
            "validity"=> "周期",
            "affect_scale"=> 100,
            "score"=> 100,
            "weight"=> "0.22",
            "status"=> 100,
            "version"=> 0,
            "algorithm"=> "根据A端客户详情-信用信息模块中的标记进行给分",
            "created_at"=> "2017-02-14 10:20:13",
            "updated_at"=> "2017-02-18 18:21:41",
            "base_type_display"=> "基本信息",
            "secondary_type_display"=> "运营类",
            "active_type_display"=> "立即生效",
            "compute_base_display"=> "标记",
            "status_display"=> "是",
            "affect_scale_display"=> "加项"
		),
		1 => array(
			"id"=> 1,
			"name"=> "企业性质",
			"base_type"=> 100,
			"secondary_type"=> 100,
			"rate_role"=> "FLBP",
			"desc"=> "企业性质",
			"compute_base"=> "100",
			"active_type"=> "100",
			"compute_time"=> "创建",
			"validity"=> "周期",
			"affect_scale"=> 100,
			"score"=> 100,
			"weight"=> "0.22",
			"status"=> 100,
			"version"=> 0,
			"algorithm"=> "根据A端客户详情-信用信息模块中的标记进行给分",
			"created_at"=> "2017-02-14 10:20:13",
			"updated_at"=> "2017-02-18 18:21:41",
			"base_type_display"=> "基本信息",
			"secondary_type_display"=> "运营类",
			"active_type_display"=> "立即生效",
			"compute_base_display"=> "标记",
			"status_display"=> "是",
			"affect_scale_display"=> "加项"
		)
	),
	detail => array(
		"id"=> 1,
		"name"=> "企业性质",
		"base_type"=> 100,
		"secondary_type"=> 100,
		"rate_role"=> "FLBP",
		"desc"=> "企业性质",
		"compute_base"=> "100",
		"active_type"=> "100",
		"compute_time"=> "创建",
		"validity"=> "周期",
		"affect_scale"=> 100,
		"score"=> 100,
		"weight"=> "0.22",
		"status"=> 100,
		"version"=> 0,
		"algorithm"=> "根据A端客户详情-信用信息模块中的标记进行给分",
		"created_at"=> "2017-02-14 10:20:13",
		"updated_at"=> "2017-02-18 18:21:41",
		"base_type_display"=> "基本信息",
		"secondary_type_display"=> "运营类",
		"active_type_display"=> "立即生效",
		"compute_base_display"=> "标记",
		"status_display"=> "是",
		"affect_scale_display"=> "加项"
	),
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('finance_credit/quotaDetail.tpl');
