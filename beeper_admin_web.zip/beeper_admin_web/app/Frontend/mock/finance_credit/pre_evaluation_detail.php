<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
		"pre_data" => array(
				'created_at'=> '2017-01-01 01:01:01',
	            'cuid'=>147,
	            'name'=>'云鸟',
	            'score'=>78,#总分
	            'score_aptitude'=>15,#资质类
	            'score_operation'=>42,#运营类平均分,
	           	'avg_score_operation'=>42,#运营类平均分
			),
			"pagination" => array(
				"total" => 16,
				"total_pages" => 4
			),
			"list" => array(
				0 => array(
					'id'=>2,
	                'secondary_type_display'=>"资质类",
	                'feature_id'=>2,#指标id
	                'feature_detail_id'=>13,#指标明细id
	                'feature_detail_name'=>'上市公司',#指标明细项名称
	                'label'=>'上市公司',#标签
	                'value'=>50,#分值
	                'score'=>40,#得分
	                'weight'=>1#权重
				),
				1 => array(
					'id'=>2,
	                'secondary_type_display'=>资质类,
	                'feature_id'=>2,#指标id
	                'feature_detail_id'=>13,#指标明细id
	                'feature_detail_name'=>'上市公司',#指标明细项名称
	                'label'=>'上市公司',#标签
	                'value'=>50,#分值
	                'score'=>40,#得分
	                'weight'=>1#权重
				),
				2 => array(
					'id'=>2,
	                'secondary_type_display'=>资质类,
	                'feature_id'=>2,#指标id
	                'feature_detail_id'=>13,#指标明细id
	                'feature_detail_name'=>'上市公司',#指标明细项名称
	                'label'=>'上市公司',#标签
	                'value'=>50,#分值
	                'score'=>60,#得分
	                'weight'=>2#权重
				)
			)
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('finance_credit/pre_evaluation_detail.tpl');
