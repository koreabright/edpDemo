module.exports = {
    '/api/v1/feature/list': '/mock/finance_credit/quotaList.json',
    '/api/v1/feature/detail/list': '/mock/finance_credit/quotaDetail.json'
};
