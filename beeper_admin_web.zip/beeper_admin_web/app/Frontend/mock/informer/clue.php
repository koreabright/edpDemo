<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    "config"=>array(
        "clue_status"=>array(
            "untreated"=>array(
                "code"=>1,
                "desc"=>"未处理"
            ),
            "pass"=>array(
                "code"=>2,
                "desc"=>"审核通过"
            ),
            "decline"=>array(
                "code"=>3,
                "desc"=>"审核拒绝"
            )
        ),
        "status_change_reason" => array(
            "phone_wrong"=>array(
                "code"=>1,
                "desc"=>"电话错误"
            ),
            "no_need"=>array(
                "code"=>2,
                "desc"=>"无用车需求"
            ),
            "no_pattern_match"=>array(
                "code"=>3,
                "desc"=>"模式不匹配"
            ),
            "other"=>array(
                "code"=>4,
                "desc"=>"其它"
            )
        ),
        "candidate_status"=>array(
            "untreated"=>array(
                "code"=>1,
                "desc"=>"未处理"
            ),
            "pass"=>array(
                "code"=>2,
                "desc"=>"审核通过"
            ),
            "decline"=>array(
                "code"=>3,
                "desc"=>"审核拒绝"
            )
        ),
        "clue_from"=>array(
            "informant"=>array(
                "code"=>1,
                "desc"=>"线人线索"
            )
        ),
        "customer_trade"=>array(
            "zhike"=>array(
                "code"=>1,
                "desc"=>"直客"
            ),
            "partner"=>array(
                "code"=>1,
                "desc"=>"SCS"
            )
        ),
        "overall_type"=>array(
            "1"=>array(
                "code"=>1,
                "desc"=>"非统筹"
            ),
            "2"=>array(
                "code"=>2,
                "desc"=>"统筹主线索"
            ),
            "3"=>array(
                "code"=>3,
                "desc"=>"统筹副线索"
            )
        ),
        "province"=>array(
            0=>array(
                "id"=>1,
                "code"=> 110000,
                "name"=>"北京市"
            ),
            1=>array(
                "id"=>2,
                "code"=> 110002,
                "name"=>"上海市"
            )
        ),
        "city"=>array(
            "1"=>array(
                0=>array(
                    "id"=> 5,
                    "name"=> "哥谭市",
                    "adc_id"=> 5,
                    "province_id"=> 3227,
                    "traffic_limit"=> 1,
                    "enable_driver"=> 1,
                    "enable_warehouse"=> 1,
                    "default_addr"=> "",
                    "default_addr_lot"=> 0,
                    "default_addr_lat"=> 0,
                    "coord_sys"=> 0
                )
            ),
            "2"=>array(
                0=>array(
                    "id"=> 5,
                    "name"=> "哥谭市11",
                    "adc_id"=> 5,
                    "province_id"=> 3227,
                    "traffic_limit"=> 1,
                    "enable_driver"=> 1,
                    "enable_warehouse"=> 1,
                    "default_addr"=> "",
                    "default_addr_lot"=> 0,
                    "default_addr_lat"=> 0,
                    "coord_sys"=> 0
                )
            )
        ),
        "permissions"=>array(
            "is_exportalbe"=>true,
            "is_editable"=>true,
            "is_sales"=>1
        )
    )
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('informer/clue.tpl');
