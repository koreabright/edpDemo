<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    "config"=>array(
        "informant_category"=>array(
            "logistics"=> array(
                "code"=> 1,
                "desc"=> "物流类"
            ),
            "medicine"=>array(
                "code"=> 2,
                "desc"=> "医药类"
            ),
             "fmcg" => array(
                "code"=> 3,
                "desc"=> "快消品"
            ),
            "food_ingredients" => array(
                "code"=> 4,
                "desc"=> "餐饮食材"
            )
        ),
        "informant_occupation"=>array(
            "logistics"=> array(
                "code"=> 1,
                "desc"=> "律师"
            ),
            "medicine"=>array(
                "code"=> 2,
                "desc"=> "程序员"
            ),
             "fmcg" => array(
                "code"=> 3,
                "desc"=> "产品经理"
            ),
            "food_ingredients" => array(
                "code"=> 4,
                "desc"=> "项目经理"
            )
        ),
        "informant_professional_level"=>array(
            "logistics"=> array(
                "code"=> 1,
                "desc"=> "律师"
            ),
            "medicine"=>array(
                "code"=> 2,
                "desc"=> "程序员"
            ),
             "fmcg" => array(
                "code"=> 3,
                "desc"=> "产品经理"
            ),
            "food_ingredients" => array(
                "code"=> 4,
                "desc"=> "项目经理"
            )
        ),
        "province"=>array(
            0=>array(
                "id"=>1,
                "code"=> 110000,
                "name"=>"北京市"
            ),
            1=>array(
                "id"=>2,
                "code"=> 110002,
                "name"=>"上海市"
            )
        ),
        "city"=>array(
            "1"=>array(
                0=>array(
                    "id"=> 5,
                    "name"=> "哥谭市",
                    "adc_id"=> 5,
                    "province_id"=> 3227,
                    "traffic_limit"=> 1,
                    "enable_driver"=> 1,
                    "enable_warehouse"=> 1,
                    "default_addr"=> "",
                    "default_addr_lot"=> 0,
                    "default_addr_lat"=> 0,
                    "coord_sys"=> 0
                )
            ),
            "2"=>array(
                0=>array(
                    "id"=> 5,
                    "name"=> "哥谭市11",
                    "adc_id"=> 5,
                    "province_id"=> 3227,
                    "traffic_limit"=> 1,
                    "enable_driver"=> 1,
                    "enable_warehouse"=> 1,
                    "default_addr"=> "",
                    "default_addr_lot"=> 0,
                    "default_addr_lat"=> 0,
                    "coord_sys"=> 0
                )
            )
        ),
        "permissions"=>array(
            "is_exportalbe"=>true,
            "is_editable"=>true,
            "is_editable_bd"=>true
        )
    )
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('informer/informerList.tpl');
