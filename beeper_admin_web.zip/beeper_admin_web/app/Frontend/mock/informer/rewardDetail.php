<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    "id" => 1,
    "name"=> "陈累",
    "business_development"=>"拍档所属bd",
    "channel" => "ref",
    "created_at"=> "2017-04-30",
    "total_award_payoff_amount"=>1234
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('informer/rewardDetail.tpl');
