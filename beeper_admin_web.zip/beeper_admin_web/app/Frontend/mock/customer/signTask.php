<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);


//$fis_data["user"] = $user;
//$fis_data["menu"] = $user_permissions;

$fis_data = array(
    view => "niaoyan",
    customer => array(
        "is_open_contract" => 1,
        "is_open_operation_data" => 1,
        is_open_manage_receipt => false,
		receipt_sendee => '斯克',
		receipt_contacts => '18000000000',
		receipt_describe => '的快乐圣诞节圣诞快乐减肥的失联客机',
		is_with_running_task => true,
		is_open_arrive_abnormal_record => true
    ),
    permission => array(
		niaoyan_editable => true,
		message_showable => true,
		package_showable => true,
		welfare_showable => true,
		subsidy_showable => true,
		credit_showable => true,
		invoice_showable=> true,
		contract_showable => true,
		lanshou_showable => true,
		crm_showable => true,
		bill_showable => true,
		base_showable => true,
		insurance_showable => true,
		pod_showable => true,
		sop_showable => true,
		temp_ctrl_showable => true,
		niaoyan_showable => true
    )
);

$smarty -> assign('info', $fis_data);
$smarty->display('customer/signTask.tpl');
