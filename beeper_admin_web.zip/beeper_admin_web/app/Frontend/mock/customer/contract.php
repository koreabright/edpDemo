<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);

$fis_data = json_decode(file_get_contents('../customer/contract.json'), true);

//$fis_data["user"] = $user;
//$fis_data["menu"] = $user_permissions;

$smarty -> assign('info', $fis_data);
$smarty->display('customer/contract.tpl');
