module.exports = {
	'/new/api/customer/company/detail': '/mock/customer/data/companyDetail.json',
	'/new/api/customer/company/detail/customer_list': '/mock/customer/data/customer_list.json',
	'/new/api/customer/company/customer_detail': '/mock/customer/data/customers.json',
	'/new/api/customer/company/update_real_name_cert': '/mock/customer/data/changeStatus.json',
	'/new/api/customer/company/update_ka_type': '/mock/customer/data/ka_type.json',
	'/new/api/customer/company/update_admin_account': '/mock/customer/data/admin_account.json',
	'/new/api/customer/company/get_group_list': '/mock/customer/data/group.json',
	'/new/api/customer/company/get_base_config': '/mock/customer/data/get_base_config.json',
	'/new/api/customer/company/list': '/mock/customer/data/customers_list.json',

	// 集团
	'/new/api/customer/group/list': '/mock/customer/groupList.json',
	'/new/api/customer/group/detail': '/mock/customer/groupDetail.json',
	'/new/api/customer/group/detail/company_list': '/mock/customer/groupDetailCompanyList.json',
	'/new/api/customer/group/update_admin_account': '/mock/customer/save.json',
	'/new/api/customer/group/update': '/mock/customer/save.json',

	// 销售联想接口
	'/new/api/customer/admin_user_suggest': '/mock/customer/saleSuggest.json',
	'/new/api/customer/get_bidmgr_by_sales': '/mock/customer/saleCallback.json',
	'/new/api/customer/get_customer_phone': '/mock/customer/telephone.json',
	'/new/api/customer/insert': '/mock/customer/save.json',
	'/new/api/customer/update_base': '/mock/customer/save.json',
	'/new/api/customer/save_image': '/mock/customer/save.json',
	'/new/api/customer/list': '/mock/customer/customerListSearch.json',
	'/new/api/customer/suggest': '/mock/prosecutionCenter/customer_name.json',
	'/new/api/customer/adc_suggest': '/mock/customer/data/adcSuggest.json',
	'/new/api/customer/set_grant_op': '/mock/customer/data/open.json',
	'/new/api/customer/company/is_normal_company': '/mock/success.json',
	'/new/api/customer/company/target_list': '/mock/customer/targetCompanyList.json',
	'/new/api/customer/company/insert_target': '/mock/success.json',
	'/new/api/customer/company/city/get_province_list': '/mock/informer/provinces.json',
	"/new/api/customer/company/city/get_city_by_province": '/mock/informer/cities.json',
	'/new/api/customer/company/get_customer_trade': '/mock/customer/data/customer_trade.json',
	'/new/api/customer/company/get_effective': '/mock/customer/data/checkCompany.json',

	// 客户审核
	'/new/api/customer_audit/list': '/mock/customer/data/checkCustomerList.json'

};
