<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);

$fis_data = array(
    id => 14,
    features => array(
        save_enable => 1, //保存按钮是否展示(1:是 ,0:否)
        save_account_enable => 1 //"创建/更新集团管理员账号"按钮是否展示(1:是, 0:否)
    )
);

//$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;

$smarty -> assign('info', $fis_data);
$smarty->display('customer/groupDetail.tpl');
