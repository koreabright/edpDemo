<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$fis_data = array(
    'group' => array(
        0 => array(
            'id' => '111',
            'name' => 'group111'
        ),
        1 => array(
            'id' => '222',
            'name' => 'group222'
        ),
        3 => array(
            'id' => '333',
            'name' => 'group333'
        )
    ),
    'config' => array(
        "cooperate_status"=>array(
            "non_cooperation" => array(
                "code"=>0,
                "desc"=>"未合作"
            ),
            "cooperation" => array(
                "code"=>1,
                "desc"=>"已合作"
            ),
            "not_cooperation" => array(
                "code"=>2,
                "desc"=>"不合作"
            )
        )
    )
);

$smarty -> assign('info', $fis_data);
$smarty->display('customer/companyList.tpl');
