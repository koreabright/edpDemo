<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$fis_data = json_decode(file_get_contents('../customer/checkCustomerMessage.json'), true);


$smarty -> assign('info', $fis_data);
$smarty->display('customer/checkCustomerMessage.tpl');
