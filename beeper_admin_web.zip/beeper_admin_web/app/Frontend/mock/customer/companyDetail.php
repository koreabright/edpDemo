<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);

$fis_data = array(
    // id => 14
);

$smarty -> assign('info', $fis_data);
$smarty->display('customer/companyDetail.tpl');
