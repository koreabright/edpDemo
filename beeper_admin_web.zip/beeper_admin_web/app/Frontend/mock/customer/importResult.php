<?php
require('../initer.php');
$user = json_decode(file_get_contents('../common/user.json'), true);
$user_permissions = json_decode(file_get_contents('../common/user_permissions.json'), true);
$fis_data = array(
    "success_count"=>10,
    "failed_count"=>20,
    "error_message_list"=>array(
        0=>array(
            "row"=>1,
            "message"=>"xxxxx"
        ),
        1=>array(
            "row"=>1,
            "message"=>"11111"
        ),
        2=>array(
            "row"=>1,
            "message"=>"22222"
        )
    )
);

$fis_data["user"] = $user;
$fis_data["menu"] = $user_permissions;
$smarty -> assign('info', $fis_data);

$smarty->display('customer/importResult.tpl');
