<?php
require('../initer.php');

$info = [
];

$smarty->assign('info', $info);
$smarty->display('BuManage/gmvTarget.tpl');
?>