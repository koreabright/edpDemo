<?php
require('../initer.php');

$titles = [
    [
        title=> '操作账号',
        field=> 'name'
    ],
    [
        title=> '操作人',
        field=> 'nick'
    ],
    [
        title=> '操作平台',
        field=> 'from_display'
    ],
    [
        title=> '操作时间',
        field=> 'cts'
    ],
    [
        title=> '变更前内容',
        field=> 'before_display'
    ],
    [
        title=> '变更后内容',
        field=> 'after_display'
    ]
  ];

$info = [
  'titles' => json_encode($titles)
];


$smarty->assign('info', $info);
$smarty->display('log/operatorLog.tpl');
