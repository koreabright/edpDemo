<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/carTypeList.json'), true);

$smarty->assign('info', $info);
$smarty->display('developer/carType.tpl');
