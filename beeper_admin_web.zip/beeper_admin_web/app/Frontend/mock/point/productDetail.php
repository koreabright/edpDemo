<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/productDetail.json'), true);

$smarty->assign('info', $info);
$smarty->display('point/productDetail.tpl');
?>
