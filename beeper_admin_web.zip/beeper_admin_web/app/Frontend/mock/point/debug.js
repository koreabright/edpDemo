module.exports = {
	"/new/api/driver_product/get_product_list": "/mock/point/data/productList.json",
	"/new/api/driver_product/product_edit": "/mock/point/data/productList.json",
	"/new/api/driver_product/logs": "/mock/point/data/productLogs.json"
};
