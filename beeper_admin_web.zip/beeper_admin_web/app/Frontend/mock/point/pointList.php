<?php
require('../initer.php');

$info = json_decode(file_get_contents('./data/pointList.json'), true);

$smarty->assign('info', $info);
$smarty->display('point/pointList.tpl');
?>