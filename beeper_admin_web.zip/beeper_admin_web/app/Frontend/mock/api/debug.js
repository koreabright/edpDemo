module.exports = {
	'/new/api/captcha_challenge': '/mock/bill/data/succ.json',
	// 添加客户
	'/new/api/admin_user/add': '/mock/success.json',
	// 辅助管理
	'/new/api/reminder/message_notification/list': '/mock/helpManage/searchData.json',
	'/new/api/message_notification/customer/save': '/mock/helpManage/msg.json',
	// 运作主管面试
	// 重复'/new/api/customer/suggest':'/mock/operate/customer_name.json',// 客户名称
	'/new/api/fcc/interview/list': '/mock/operate/list.json', // 面试列表页列表
	'/new/api/fcc/interview/auto_message': '/mock/operate/autoMessage.json', // 所属管理区
	'/new/api/fcc/interview/add_fcc': '/mock/operate/inquire.json', // 查询
	'/new/api/fcc/interview/delete_fcc': '/mock/operate/inquire.json', // 删除
	'/new/api/fcc/interview/fcc_log': '/mock/operate/fcc_log.json', // 面试日志

	'/new/api/prosecutor/phone_num_inquiry': '/mock/prosecutionCenter/searchData.json', // 检察中心手机号查询

	// 部门客户管理
	'/new/api/dep/getDep': '/mock/departmentUserManage/data/tree.json', // 获取部门树

	// 短信模块
	'/new/api/sms/black/search': '/mock/sms/searchMobile.json', // 黑名单列表-查询
	'/new/api/sms/black/save': '/mock/sms/saveMobile.json', // 黑名单列表-新增号码
	'/new/api/sms/black/delete': '/mock/sms/deleteMobile.json', // 黑名单列表-删除号码
	'/new/api/sms/blacklog/search': '/mock/sms/blackOperationLogSearch.json', // 短信管理 - 黑名单操作日志 - 查询
	'/new/api/sms/log/search': '/mock/sms/smslogSearch.json', // 辅助工具-发送短信列表查询
	'/new/api/sms/count/search': '/mock/sms/countSearch.json', // 辅助工具 - 短信统计页面查询
	'/new/api/sms/config/scene': '/mock/sms/sceneSuggest.json', // 辅助工具 - 短信统计页面查询 - 发送场景 suggest
	// 短信模块结束

	'/new/api/log/lists': '/mock/log/data/log.json',
	'/new/api/trans_event/calendar/list': '/mock/transMonitor/data/list.json',
	'/new/api/trans_event/calendar/todo_list': '/mock/transMonitor/data/todo_list.json',
	'/new/api/trans_event/calendar/track': '/mock/transMonitor/data/trace.json',

	// 司机邀请统计列表页面
	'/new/api/driver_invite/list': '/mock/driver/data/list.json',

	// 车贴列表/物品检查
	'/new/api/driver_item_inspection/list': '/mock/driver/data/goods_list.json',
	'/new/api/driver_work_clothes_inspection/list': '/mock/driver/data/workClothes.json',

	// suggest
	'/new/api/adminuser/suggest': '/mock/suggest/adminUser.json',
	'/new/api/driver/suggest': '/mock/suggest/adminUser.json',
	'/new/api/warehouse/suggest': '/mock/suggest/adminUser.json',
	'/new/api/trans_event/calendar/detail': '/mock/transMonitor/data/detail.json',
	'/new/api/customer_clue/informant/suggest': '/mock/suggest/adminUser.json',
	'/new/api/customer_clue/admin_user/suggest': '/mock/suggest/adminUser.json',
	'/new/api/customer_clue/charge_admin/suggest': '/mock/suggest/adminUser.json',
	'/new/api/customer_clue/charge_user/suggest': '/mock/suggest/adminUser.json',
	'/new/api/driver_transaction/get_product_suggest': '/mock/suggest/productList.json',
	// 客户详情上传照片
	'/new/api/image/upload': '/mock/customer/upload_picture.json',
	'/new/api/adc/suggest': '/mock/suggest/adminUser.json', // 所属管理区
	'/new/api/cartype/suggest': '/mock/suggest/adminUser.json', // 所属管理区

	// 根据客户id获取在跑司机
	'/new/api/driver/get_running_driver_by_cid': '/mock/driver/data/running_driver.json',
	// 司机物品发放
	'/new/api/driver_item_distribute/provide_by_dids': '/mock/driver/data/provide.json',
	'/new/api/driver_item_distribute/index': '/mock/driver/data/item_list.json',
	'/new/api/driver_item_distribute/update_by_driver_id': '/mock/driver/data/provide.json',
	'/new/api/driver_item_distribute/get_by_driver_id': '/mock/driver/data/driver_info.json',

	// 操作成功，失败
	'/new/api/driver_item_inspection/update': '/mock/success.json',
	'/new/api/driver_invite/update_by_invitee_driver_id': '/mock/driver/data/invite_status.json',

	'/new/api/rating/evaluation/get_list': 'mock/finance_credit/list.json',
	'/new/api/rating/evaluation/re_evaluation': 'mock/finance_credit/re_tr.json',

	// 线人相关接口
	'/new/api/customer_clue/informant/list': '/mock/informer/informer.json',
	'/new/api/customer_clue/informant/add': '/mock/success.json',
	'/new/api/customer_clue/informant/reset_password': '/mock/success.json',
	'/new/api/customer_clue/informant/set_enable': '/mock/success.json',
	'/new/api/customer_clue/informant/set_disable': '/mock/success.json',

	// 线索相关接口
	'/new/api/customer_clue/clue/list': '/mock/informer/clue.json',
	'/new/api/customer_clue/clue/get': '/mock/informer/clue_detail.json',
	'/new/api/customer_clue/clue/add': '/mock/success.json',
	'/new/api/customer_clue/clue/update': '/mock/success.json',
	'/new/api/customer_clue/clue/audit_pass': '/mock/success.json',
	'/new/api/customer_clue/clue/audit_reject': '/mock/success.json',
	'/new/api/customer_clue/batch/charge': 'mock/success.json',
	'/new/api/customer_clue/clue/candidate_source_from': 'mock/informer/status.json',
	'/new/api/customer_clue/award/getList': 'mock/informer/reward.json',
	'/new/api/customer_clue/award/payoff': 'mock/success.json',
	'/new/api/customer_clue/award/summary': 'mock/informer/summary.json',
	'/new/api/customer_clue/clue/award/summary': 'mock/informer/clue_summary.json',
	'/new/api/customer_clue/informant/award/summary': 'mock/informer/informer_summary.json',
	'/new/api/customer_clue/award/payoffList': 'mock/informer/payoff_list.json',
	'/new/api/customer_clue/clue/make_valid': 'mock/success.json',
	'/new/api/customer_clue/clue/make_invalid': 'mock/success.json',
	'/new/api/customer_clue/clue/get_remark': 'mock/informer/remark.json',
	'/new/api/customer_clue/informant/update_bd': 'mock/success.json',
	'/new/api/customer_clue/clue/get_clue_detail': '/mock/informer/clue_detail.json',
	'/new/api/customer_clue/clue/get_clue_log': '/mock/informer/log.json',
	'/new/api/customer_clue/clue/get_city_charge': '/mock/informer/handler.json',
	'/new/api/customer_clue//overall_type/config': '/mock/informer/overallType.json',
	'/new/api/customer_clue/get_clue_status': '/mock/informer/clue_status.json',
	// 统筹人
	'/new/api/customer_clue/overall_admin_user/suggest': '/mock/suggest/adminUser.json',
	'/new/api/customer_clue/overall/suggest': '/mock/suggest/adminUser.json',
	// 省市 接口
	'/new/api/customer_clue/province/all': '/mock/informer/provinces.json',
	'/new/api/customer_clue/city/get_all_by_province_id': '/mock/informer/cities.json',

	'/new/api/rating/pre_evaluation/export': 'mock/success.json',
	'/new/api/rating/pre_evaluation/export_old_admin': 'mock/success.json',

	'/new/api/finance/customer_bill/account_diff': 'mock/bill/list.json',

	'/new/api/linecenter/account_manage': 'mock/linecenter/list.json',
	'/new/api/linecenter/status': 'mock/linecenter/res.json',

	'/new/api/customer/suggest': '/mock/prosecutionCenter/customer_name.json',
	// 订单中心-结算日报调整
	'/new/api/order_center/balance_list': '/mock/orderCenter/data/dailyAdjust.json',
	// 发布空车
	'/new/api/match/get_wait_time_range_list': '/mock/driver/data/releaseEmptyCar.json',
	'/new/api/city/get_all': '/mock/driver/data/city.json',
	// 回单管理
	'/new/api/receipt/list': '/mock/receipt/data/receiptList.json',
	'/new/api/receipt/process_exception': '/mock/receipt/data/receiptList.json',
	'/new/api/receipt/update_status': '/mock/receipt/data/receiptList.json',
	'/new/api/receipt/get_supported_status': '/mock/receipt/data/receiptStatus.json',
	'/new/api/receipt/get_supported_change_status': '/mock/receipt/data/receiptStatus.json',
	'/new/api/receipt/update_config': '/mock/receipt/data/receiptList.json',
	'/new/api/tms/order': '/mock/tms/data/orderList.json',
	'/new/api/receipt/get_status_change_log': '/mock/receipt/data/receiptStatusLog.json',

	// 司机消费
	"/new/api/finance/driver_consume/list": "/mock/finance/data/driverConsume.json",
    
	// 司机积分
	'/new/api/bonus_point/get_bonus_point': '/mock/point/data/pointList.json',
	'/new/api/bonus_point/get_bonus_point_log': '/mock/point/data/pointDetails.json',
	'/new/api/driver_transaction/get_order_list': '/mock/point/data/exchangeList.json',
	'/new/api/driver_transaction/dispatch_product': '/mock/point/data/exchangeList.json',
	'/new/api/driver_transaction/batch_dispatch_product': '/mock/point/data/exchangeList.json',
	'/new/api/driver_transaction/order_log': '/mock/point/data/operationLog.json',

	// 任务相关
	'/new/task/api/list': '/mock/task/list.json',
	'/new/task/api/rescue_list': '/mock/task/rescueList.json',
	'/new/api/task/stop_task_for_dispatch': '/mock/success.json',
	'/new/task/api/abandon': '/mock/success.json',
	'/new/match/api/dispatch/list': '/mock/task/dispatch.json',

	// 平安车险购买
	'/new/api/car_insurance/get_list': '/mock/driver/data/carInsurance.json',
	'/new/api/car_insurance/update_status': '/mock/driver/data/isHaveSuccessRecord.json',
	'/new/api/car_insurance/return_money': '/mock/driver/data/isHaveSuccessRecord.json',
	'/new/api/car_insurance/is_have_success_record': '/mock/driver/data/isHaveSuccessRecord.json',

	// 用户反馈
	'/new/api/driver_feedback/get_list': '/mock/userFeedback/data/driverFeedback.json',
	'/new/api/driver_feedback_reply/get_reply': '/mock/userFeedback/data/replyInfo.json',
	// 公共运力池
	'/new/api/driver_pool/get_list': '/mock/driver/data/driverPool.json',
	// 车型管理
	'/new/api/car_type/get_second_group_list': '/mock/developer/data/secondGroupList.json',
	'/new/api/car_type/update_second_group': '/mock/developer/data/secondGroupList.json',
	'/new/api/car_type/add_second_group': '/mock/developer/data/secondGroupList.json',
	// 百灵推荐
	'/new/api/lark_service/get_recommend': '/mock/larkService/data/recommendDriverDetail.json',
	'/new/api/lark_service/price_predict': '/mock/larkService/data/recommendDriverDetail.json',
	'/new/api/lark_service/get_city_list': '/mock/larkService/data/city.json',
	'/new/api/lark_service/get_car_ids_list': '/mock/larkService/data/carType.json',

	// 获取实名认证审核列表
	'/new/api/captain/get_captain_identity_auth_list': '/mock/captain/data/captainList.json',
	// 获取车队长详细信息
	'/new/api/captain/get_captain_auth_detail': '/mock/captain/data/detailCaptain.json',
	'/new/api/captain/audit_captain_identity_info': '/mock/captain/data/return.json',
	'/new/api/captain/audit_captain_certification_info': '/mock/captain/data/return.json',
	'/new/api/captain/certification/list': '/mock/captain/data/captainListCert.json',

	// 线路认证
	'/new/api/gold_trans/task/get_list': '/mock/goldTrans/data/listTask.json',
	'/new/api/gold_trans/task/get': '/mock/goldTrans/data/detailTask.json',
	'/new/api/gold_trans/task/do_auth': '/mock/goldTrans/data/return.json',

	// 司机认证
	'/new/api/driver/get_driver_identity_list': '/mock/goldDriver/data/driverList.json',
	'/new/api/vehicle/get_vehicle_list': '/mock/goldDriver/data/driverListCar.json',
	'/new/api/driver/get_driver_auth_detail': '/mock/goldDriver/data/driverDetail.json',
	'/new/api/driver/audit_driver_identity_info': '/mock/goldDriver/data/return.json',
	'/new/api/driver/audit_vehicle_info': '/mock/goldDriver/data/return.json',

	// 出车验真
	'/new/api/gold_trans/event/get_list': '/mock/goldCheckTruly/data/goldCheckList.json',  	// 列表数据
	'/new/api/gold_trans/event/check': '/mock/goldCheckTruly/data/goldCheckRandDetails.json',		// 提交请求
	'/new/api/gold_trans/event/get': '/mock/goldCheckTruly/data/goldCheckDetails.json',			// 详情请求
	'/new/api/gold_trans/event/trail': '/mock/goldCheckTruly/data/goldCheckTrail.json', // 轨迹查看详情请求
	'/new/api/gold_trans/event/trail_coord': '/mock/goldCheckTruly/data/goldCheckTrail_coord.json', // 轨迹查看经纬度数据
	// 车队长维护
	'/new/api/captain/user/list': '/mock/goldCaptainFollow/data/captainFollow.json',			// 列表数据
	'/new/api/captain/credit/set': '/mock/goldCaptainFollow/data/setFollow.json',					// 保存接口
	'/new/api/captain/user/create': '/mock/goldCaptainFollow/data/setFollow.json',				// 车队长新增

	// 贷款审批
	'/new/api/carteam_fin/list_loan': '/mock/goldLoan/data/loanApprovalList.json',				// 列表数据
	'/new/api/carteam_fin/approve_loan': '/mock/goldCheckTruly/data/goldCheckRandDetails.json',		// 审核通过
	'/new/api/carteam_fin/make_loan': '/mock/goldCheckTruly/data/goldCheckRandDetails.json',			// 确认打款

	// 仓库管理
	'/new/api/gold_trans/warehouse/get_list': '/mock/goldWarehouse/data/warehouseManage.json',		// 仓库列表
	'/new/api/gold_trans/warehouse/update_geo': '/mock/goldCaptainFollow/data/setFollow.json',			// 保存
	// 云通话记录
	'/new/api/telephone/consignee/record': '/mock/driver/data/callLog.json',
	'/new/api/gmv_check_manager/get_list': '/mock/BuManage/data/gmvTarget.json', // gmv目标值列表
	'/new/api/gmv_check_manager/modify/get_list': '/mock/BuManage/data/gmvUpdate.json', // gmv目标值修改列表
	'/new/api/gmv_check_manager/get_config': '/mock/BuManage/data/dictionary.json'
};
