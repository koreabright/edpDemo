// npm run start 开发时开启服务
// npm run build:debug 本地发布到项目下的web目录
// npm run offline:build 联调命令

/**
 * B端编译发布配置文件
 *
 * 目前B端的开发代码在RD整体代码库的app/Fontend目录中
 * 编译后的路径在根目录的web下, 也就是../../web
 * 因此 需要提交代码前要运行fis3 release debug -d ../../web 将代码发布到目录下
 * 这里的-d参数表示发布路径 debug是当前的media的名称
 *
 */

/**
 * 和RD联调时的配置
 * 联调时需要RD机器有receiver.php文件并且可以通过根目录的方式访问。
 * 比如RD的机器地址是http://192.168.200.25:8500
 * 则要求http://192.168.200.25:8500/receiver.php是可以访问的
 * to参数是前端的代码编译后要放置到的地址
 *
 * 注意不要为了省事直接将代码发布到RD的public目录下
 * RD的public目录下除了前端的代码 还有后端的一些框架入口
 * 直接发布到public目录下会覆盖掉他们的系统文件
 *
 * 联调时直接运行fis3 release debug 就可以了 这里已经配置了路径
 */


fis.set('project.ignore', [
	'output/**',
	'*.php',
	'node_modules/**',
	'.git/**',
	'.svn/**',
	'/libs/**',
	'*.sh',
	'*.conf',
	'*.log',
	'*.md',
	'/mock/**',
	'/templates_c/**',
	'*.xlsx',
	'*.xls',
	'fis-conf.js',
	'*.json',
	'edp-*'
]);

// fis.media('offline').match('*', {
// 	deploy: fis.plugin('http-push', {
// 		receiver: 'http://192.168.204.26:3510/receiver.php ',
// 		to: '/var/www/beeper_admin_web/web'
// 	})
// });
/* 开票资质列表 */
fis.media('offline').match('*', {
	deploy: fis.plugin('http-push', {
		receiver: 'http://192.168.204.43:3510/receiver.php ',
		to: '/var/www/beeper_admin_web/web'
	})
});


// export, module, require不压缩变量名
fis.config.set('settings.optimizer.uglify-js', {
	mangle: {
		except: 'exports, module, require, define'
	}
});

fis.match('*.less', {
	// fis-parser-less 插件进行解析
	parser: fis.plugin('less'),
	// .less 文件后缀构建后被改成 .css 文件
	rExt: '.css'
});

// 添加MD5戳
// fis.match('*.{js,css,png}', {
//     useHash: false
// });

/**
 * 提交代码的时候打开注释
 * 现在fis在编译的时候 windows下会出现结尾换行符为CTRF
 * 因为我们和RD公用一个代码库 导致他们每次check代码的时候有大片的modify
 * 压缩可以解决这个问题 所以提交代码的时候压缩一下
 */

fis.media('debug').match('/srcstatic/src/js/**/*.js', {
	optimizer: fis.plugin('uglify-js'),
	parser: fis.plugin('babel-6.x', {
		sourceMaps: true,
		presets: [["es2015", { "modules": false }]]
	}),
	useHash: true
});

fis.media('test').match('/srcstatic/src/js/es6test.js', {
	optimizer: fis.plugin('uglify-js'),
	parser: fis.plugin('babel-5.x'),
	useHash: true
});


fis.media('debug').match('*.tpl', {
	optimizer: fis.plugin('tpl-compress')
});

fis.media('debug').match('/srcstatic/src/css/**/*.{less}', {
	useHash: true,
	optimizer: fis.plugin('clean-css')
});

/* 联调的时候不需要useHash 所以在这里新启动一个media */
fis.media('offline').match('/srcstatic/src/css/**/*.{css,less}', {
	optimizer: fis.plugin('clean-css')
});

// 联调的时候解析ES6 如果不需要解析就注释掉babel那一段
// fis.media('offline').match('/srcstatic/src/js/**/*.js', {
// 	useHash: false,
// 	parser: fis.plugin('babel-6.x', {
// 		sourceMaps: true,
// 		presets: [["es2015", { "modules": false }]]
// 	})
// });
fis.media('offline').match('*.tpl', {
	optimizer: false
});
