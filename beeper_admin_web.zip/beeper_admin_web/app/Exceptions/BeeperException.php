<?php

namespace App\Exceptions;

use Exception;

/**
 * Beeper异常,用来指定处理过程中的Error级别
 */
class BeeperException extends Exception
{
    private $logLevel;

    public function __construct($message = "", $code = 0, Exception $previous = null, $logLevel = 'error')
    {
        $this->message = $message;
        $this->code = ($code == 0 ? config('custom_code.service_error.code') : $code);
        $this->logLevel = $logLevel;
    }

    public function getLogLevel(){
        return $this->logLevel;
    }
}
