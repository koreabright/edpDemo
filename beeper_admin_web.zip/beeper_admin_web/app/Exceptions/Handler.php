<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Session\TokenMismatchException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Illuminate\Validation\ValidationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Response;
use Illuminate\Http\JsonResponse;

use Log;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        AuthorizationException::class,
        HttpException::class,
        ModelNotFoundException::class,
        ValidationException::class,
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  \Exception $e
     * @return void
     */
    public function report(Exception $e)
    {
        return parent::report($e);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Exception $e
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $e)
    {
        if ($e instanceof ModelNotFoundException) {
            $e = new NotFoundHttpException($e->getMessage(), $e);
        }

        if ($e instanceof BeeperException) {
            $this->logException($request, $e, $e->getLogLevel());
        } elseif ($e instanceof HttpException) {
            $this->logException($request, $e, 'warning');
        } else {
            $this->logException($request, $e);
        }

        //TODO : 通过 new/api 区分是否是API请求
        if ($request->is('new/*api/*')) {
            //Return json format instead of rendering error pages.
            return $this->renderApiException($e);
        }

        return parent::render($request, $e);
    }

    private function logException($request, Exception $e, $errorLevel = 'error')
    {
        $err = [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'code' => $e->getCode(),
            'url' => $request->url(),
            'input' => $request->all(),
        ];

        switch ($errorLevel) {
            case 'error':
                Log::error($err);
                break;
            case 'warning':
                Log::warning($err);
                break;
            default:
                Log::info($err);
        }
    }

    /**
     * Render an ApiException and return a json format error.
     *
     * @param Exception $e
     * @return mixed
     */
    private function renderApiException(Exception $e)
    {
        if ($e instanceof HttpException) {
            $response = new Response();
            $response->withException($e);
            return $response->setStatusCode($e->getStatusCode(), $e->getMessage())->send();
        } elseif ($e instanceof TokenMismatchException) {
            $response = new JsonResponse();
            return $response->setData([
                'code' => $e->getCode() ? $e->getCode() : config('custom_code.server_error.code'),
                'msg' => '操作失败,请刷新页面后重试',
            ]);
        } else {
            $response = new JsonResponse();
            return $response->setData([
                'code' => $e->getCode() ? $e->getCode() : config('custom_code.server_error.code'),
                'msg' => $e->getMessage(),
            ]);
        }
    }
}
